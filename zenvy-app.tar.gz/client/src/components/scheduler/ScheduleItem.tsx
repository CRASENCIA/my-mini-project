import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Schedule } from "@shared/schema";
import { Check, Clock, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface ScheduleItemProps {
  schedule: Schedule;
  onComplete: (id: number) => void;
  onDelete: (id: number) => void;
}

export function ScheduleItem({ schedule, onComplete, onDelete }: ScheduleItemProps) {
  // Format time from date
  const formatTime = (date: string) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  // Get background color based on schedule type
  const getTypeColor = (type: string) => {
    switch (type) {
      case "skincare":
        return "bg-pink-100 text-pink-800";
      case "haircare":
        return "bg-blue-100 text-blue-800";
      case "health":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };
  
  return (
    <Card className={cn(
      "overflow-hidden", 
      schedule.isCompleted ? "bg-gray-50 opacity-75" : "bg-white"
    )}>
      <CardContent className="p-0">
        <div className="p-3 flex items-center">
          <div className="flex-1 pr-4">
            <div className="flex items-center mb-1">
              <span className={cn(
                "text-xs px-2 py-0.5 rounded-full mr-2",
                getTypeColor(schedule.type)
              )}>
                {schedule.type.charAt(0).toUpperCase() + schedule.type.slice(1)}
              </span>
              <span className="text-xs text-gray-500 flex items-center">
                <Clock className="h-3 w-3 mr-1" />
                {formatTime(schedule.startTime)}
              </span>
            </div>
            <h3 className={cn(
              "font-medium", 
              schedule.isCompleted ? "text-gray-500 line-through" : "text-gray-900"
            )}>
              {schedule.title}
            </h3>
            {schedule.description && (
              <p className={cn(
                "text-xs mt-1", 
                schedule.isCompleted ? "text-gray-400" : "text-gray-600"
              )}>
                {schedule.description}
              </p>
            )}
          </div>
          
          <div className="flex space-x-1">
            {!schedule.isCompleted && (
              <Button 
                variant="outline" 
                size="sm" 
                className="h-8 w-8 p-0" 
                onClick={() => onComplete(schedule.id)}
              >
                <Check className="h-4 w-4 text-green-600" />
              </Button>
            )}
            <Button 
              variant="outline" 
              size="sm" 
              className="h-8 w-8 p-0" 
              onClick={() => onDelete(schedule.id)}
            >
              <Trash2 className="h-4 w-4 text-red-600" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
