import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface BMICalculatorProps {
  onSave: (weight: number, height: number) => void;
  onCancel: () => void;
  initialWeight?: number;
  initialHeight?: number;
  isLoading?: boolean;
}

export function BMICalculator({
  onSave,
  onCancel,
  initialWeight = 60,
  initialHeight = 170,
  isLoading = false,
}: BMICalculatorProps) {
  const [weight, setWeight] = useState<number>(initialWeight || 60);
  const [height, setHeight] = useState<number>(initialHeight || 170);
  const [bmi, setBmi] = useState<number | null>(null);
  
  const calculateBMI = () => {
    if (weight > 0 && height > 0) {
      const heightInMeters = height / 100;
      const calculatedBMI = weight / (heightInMeters * heightInMeters);
      setBmi(parseFloat(calculatedBMI.toFixed(1)));
    }
  };
  
  // Get BMI category and color
  const getBMICategory = (bmi: number): { category: string; color: string } => {
    if (bmi < 18.5) return { category: "Underweight", color: "text-blue-600" };
    if (bmi < 25) return { category: "Normal weight", color: "text-green-600" };
    if (bmi < 30) return { category: "Overweight", color: "text-orange-600" };
    return { category: "Obese", color: "text-red-600" };
  };
  
  // Handle save
  const handleSave = () => {
    onSave(weight, height);
  };
  
  return (
    <Card className="shadow-md">
      <CardHeader>
        <CardTitle className="text-xl text-purple-800">BMI Calculator</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="weight">Weight (kg)</Label>
            <Input
              id="weight"
              type="number"
              value={weight}
              onChange={(e) => setWeight(Number(e.target.value))}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="height">Height (cm)</Label>
            <Input
              id="height"
              type="number"
              value={height}
              onChange={(e) => setHeight(Number(e.target.value))}
            />
          </div>
          
          <Button 
            className="w-full bg-purple-800 hover:bg-purple-900"
            onClick={calculateBMI}
          >
            Calculate BMI
          </Button>
        </div>
        
        {bmi !== null && (
          <div className="p-4 bg-gray-50 rounded-lg text-center">
            <h3 className="text-sm text-gray-600 mb-1">Your BMI is</h3>
            <p className="text-4xl font-bold mb-1">{bmi}</p>
            <p className={`text-sm font-medium ${getBMICategory(bmi).color}`}>
              {getBMICategory(bmi).category}
            </p>
          </div>
        )}
        
        <div className="space-y-2 text-sm text-gray-600">
          <p className="font-medium">BMI Categories:</p>
          <ul className="space-y-1">
            <li className="flex justify-between">
              <span>Underweight</span>
              <span className="text-blue-600">Less than 18.5</span>
            </li>
            <li className="flex justify-between">
              <span>Normal weight</span>
              <span className="text-green-600">18.5 - 24.9</span>
            </li>
            <li className="flex justify-between">
              <span>Overweight</span>
              <span className="text-orange-600">25 - 29.9</span>
            </li>
            <li className="flex justify-between">
              <span>Obesity</span>
              <span className="text-red-600">30 or greater</span>
            </li>
          </ul>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button 
          className="bg-purple-800 hover:bg-purple-900"
          onClick={handleSave}
          disabled={isLoading}
        >
          {isLoading ? "Saving..." : "Save Results"}
        </Button>
      </CardFooter>
    </Card>
  );
}
