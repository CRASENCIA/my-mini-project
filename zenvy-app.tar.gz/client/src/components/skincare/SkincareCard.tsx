import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SkincareRoutine } from "@shared/schema";
import { Clock } from "lucide-react";
import { Link } from "wouter";

interface SkincareCardProps {
  routine: SkincareRoutine;
}

export function SkincareCard({ routine }: SkincareCardProps) {
  // Parse steps from JSON
  const steps = routine.steps ? (typeof routine.steps === 'string' ? JSON.parse(routine.steps as string) : routine.steps) : [];
  
  // Format time of day for display
  const formatTimeOfDay = (timeOfDay: string) => {
    switch (timeOfDay) {
      case "morning":
        return "Morning Routine";
      case "evening":
        return "Evening Routine";
      case "weekly":
        return "Weekly Routine";
      default:
        return timeOfDay.charAt(0).toUpperCase() + timeOfDay.slice(1);
    }
  };
  
  return (
    <Card className="overflow-hidden shadow-sm">
      <CardContent className="p-0">
        <div className="p-4 border-b">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-semibold text-purple-900">{routine.name}</h3>
            <div className="flex items-center text-xs text-gray-500">
              <Clock className="h-3 w-3 mr-1" />
              <span>{formatTimeOfDay(routine.timeOfDay)}</span>
            </div>
          </div>
          
          {routine.description && (
            <p className="text-sm text-gray-600 mb-2">{routine.description}</p>
          )}
          
          <div className="mt-3">
            <p className="text-xs text-gray-500 uppercase tracking-wide mb-2">Steps:</p>
            <ul className="text-sm space-y-1">
              {steps.slice(0, 3).map((step: any, index: number) => (
                <li key={index} className="flex items-start">
                  <span className="text-purple-600 font-medium mr-2">{index + 1}.</span>
                  <span className="text-gray-700">{step.name || step.product}</span>
                </li>
              ))}
              {steps.length > 3 && (
                <li className="text-purple-600 text-sm">+ {steps.length - 3} more steps</li>
              )}
            </ul>
          </div>
        </div>
        
        <div className="flex divide-x">
          <Link href={`/skincare-routine/${routine.id}`} className="flex-1">
            <Button variant="ghost" className="w-full rounded-none h-12 text-purple-700">
              View Details
            </Button>
          </Link>
          <Button variant="ghost" className="flex-1 rounded-none h-12 text-purple-700">
            Start Now
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
