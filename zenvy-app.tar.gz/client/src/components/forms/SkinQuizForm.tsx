import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

// Form schema
const skinQuizSchema = z.object({
  skinType: z.string().min(1, "Please select a skin type"),
  skinConcerns: z.array(z.string()).min(1, "Please select at least one concern"),
  skinSensitivity: z.string().min(1, "Please select sensitivity level"),
  skinOiliness: z.string().min(1, "Please select oiliness level"),
  currentProducts: z.array(z.string()).optional(),
  breakoutFrequency: z.string().min(1, "Please select breakout frequency"),
  environmentalFactors: z.array(z.string()).optional(),
});

type SkinQuizFormValues = z.infer<typeof skinQuizSchema>;

interface SkinQuizFormProps {
  onComplete: (data: SkinQuizFormValues) => void;
}

export function SkinQuizForm({ onComplete }: SkinQuizFormProps) {
  const [step, setStep] = useState(1);
  const totalSteps = 5;
  
  const form = useForm<SkinQuizFormValues>({
    resolver: zodResolver(skinQuizSchema),
    defaultValues: {
      skinType: "",
      skinConcerns: [],
      skinSensitivity: "",
      skinOiliness: "",
      currentProducts: [],
      breakoutFrequency: "",
      environmentalFactors: [],
    },
  });
  
  const nextStep = () => {
    setStep((prev) => Math.min(prev + 1, totalSteps));
  };
  
  const prevStep = () => {
    setStep((prev) => Math.max(prev - 1, 1));
  };
  
  const onSubmit = (data: SkinQuizFormValues) => {
    onComplete(data);
  };
  
  const progress = (step / totalSteps) * 100;
  
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Progress value={progress} className="h-2" />
        <p className="text-sm text-gray-500 text-right">Step {step} of {totalSteps}</p>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {step === 1 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-purple-800">Basic Skin Information</h2>
              
              <FormField
                control={form.control}
                name="skinType"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>What is your skin type?</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="oily" />
                          </FormControl>
                          <FormLabel className="font-normal">Oily Skin</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="dry" />
                          </FormControl>
                          <FormLabel className="font-normal">Dry Skin</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="combination" />
                          </FormControl>
                          <FormLabel className="font-normal">Combination Skin</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="normal" />
                          </FormControl>
                          <FormLabel className="font-normal">Normal Skin</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}
          
          {step === 2 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-purple-800">Skin Concerns</h2>
              
              <FormField
                control={form.control}
                name="skinConcerns"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>What are your skin concerns? (Select all that apply)</FormLabel>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {["acne", "aging", "dryness", "oiliness", "dullness", "uneven tone", "blackheads", "sensitivity"].map((concern) => (
                        <FormItem
                          key={concern}
                          className="flex items-start space-x-2 space-y-0"
                        >
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(concern)}
                              onCheckedChange={(checked) => {
                                const updatedValue = checked
                                  ? [...field.value, concern]
                                  : field.value.filter((value) => value !== concern);
                                field.onChange(updatedValue);
                              }}
                            />
                          </FormControl>
                          <FormLabel className="font-normal text-sm leading-tight">
                            {concern.charAt(0).toUpperCase() + concern.slice(1)}
                          </FormLabel>
                        </FormItem>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}
          
          {step === 3 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-purple-800">Skin Sensitivity</h2>
              
              <FormField
                control={form.control}
                name="skinSensitivity"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>How sensitive is your skin?</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="not_sensitive" />
                          </FormControl>
                          <FormLabel className="font-normal">Not sensitive</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="slightly_sensitive" />
                          </FormControl>
                          <FormLabel className="font-normal">Slightly sensitive</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="very_sensitive" />
                          </FormControl>
                          <FormLabel className="font-normal">Very sensitive</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="breakoutFrequency"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>How often do you experience breakouts?</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="rarely" />
                          </FormControl>
                          <FormLabel className="font-normal">Rarely</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="occasionally" />
                          </FormControl>
                          <FormLabel className="font-normal">Occasionally</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="frequently" />
                          </FormControl>
                          <FormLabel className="font-normal">Frequently</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}
          
          {step === 4 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-purple-800">Current Routine</h2>
              
              <FormField
                control={form.control}
                name="currentProducts"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>What products do you currently use? (Select all that apply)</FormLabel>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {["cleanser", "toner", "serum", "moisturizer", "sunscreen", "exfoliator", "mask", "oil"].map((product) => (
                        <FormItem
                          key={product}
                          className="flex items-start space-x-2 space-y-0"
                        >
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(product)}
                              onCheckedChange={(checked) => {
                                const updatedValue = checked
                                  ? [...(field.value || []), product]
                                  : (field.value || []).filter((value) => value !== product);
                                field.onChange(updatedValue);
                              }}
                            />
                          </FormControl>
                          <FormLabel className="font-normal text-sm leading-tight">
                            {product.charAt(0).toUpperCase() + product.slice(1)}
                          </FormLabel>
                        </FormItem>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}
          
          {step === 5 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-purple-800">Environmental Factors</h2>
              
              <FormField
                control={form.control}
                name="environmentalFactors"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>What environmental factors affect your skin? (Select all that apply)</FormLabel>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {["sun_exposure", "pollution", "air_conditioning", "dry_climate", "humid_climate", "frequent_travel", "stress", "lack_of_sleep"].map((factor) => (
                        <FormItem
                          key={factor}
                          className="flex items-start space-x-2 space-y-0"
                        >
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(factor)}
                              onCheckedChange={(checked) => {
                                const updatedValue = checked
                                  ? [...(field.value || []), factor]
                                  : (field.value || []).filter((value) => value !== factor);
                                field.onChange(updatedValue);
                              }}
                            />
                          </FormControl>
                          <FormLabel className="font-normal text-sm leading-tight">
                            {factor.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                          </FormLabel>
                        </FormItem>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}
          
          <div className="flex justify-between pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={prevStep}
              disabled={step === 1}
            >
              Previous
            </Button>
            
            {step < totalSteps ? (
              <Button
                type="button"
                className="bg-purple-800 hover:bg-purple-900"
                onClick={nextStep}
              >
                Next
              </Button>
            ) : (
              <Button
                type="submit"
                className="bg-purple-800 hover:bg-purple-900"
              >
                Complete Quiz
              </Button>
            )}
          </div>
        </form>
      </Form>
    </div>
  );
}
