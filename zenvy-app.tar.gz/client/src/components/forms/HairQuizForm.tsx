import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

// Form schema
const hairQuizSchema = z.object({
  hairType: z.string().min(1, "Please select a hair type"),
  hairTexture: z.string().min(1, "Please select a hair texture"),
  hairConcerns: z.array(z.string()).min(1, "Please select at least one concern"),
  scalpCondition: z.string().min(1, "Please select scalp condition"),
  hairTreatments: z.array(z.string()).optional(),
  hairProductsUsed: z.array(z.string()).optional(),
  washFrequency: z.string().min(1, "Please select wash frequency"),
});

type HairQuizFormValues = z.infer<typeof hairQuizSchema>;

interface HairQuizFormProps {
  onComplete: (data: HairQuizFormValues) => void;
}

export function HairQuizForm({ onComplete }: HairQuizFormProps) {
  const [step, setStep] = useState(1);
  const totalSteps = 5;
  
  const form = useForm<HairQuizFormValues>({
    resolver: zodResolver(hairQuizSchema),
    defaultValues: {
      hairType: "",
      hairTexture: "",
      hairConcerns: [],
      scalpCondition: "",
      hairTreatments: [],
      hairProductsUsed: [],
      washFrequency: "",
    },
  });
  
  const nextStep = () => {
    setStep((prev) => Math.min(prev + 1, totalSteps));
  };
  
  const prevStep = () => {
    setStep((prev) => Math.max(prev - 1, 1));
  };
  
  const onSubmit = (data: HairQuizFormValues) => {
    onComplete(data);
  };
  
  const progress = (step / totalSteps) * 100;
  
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Progress value={progress} className="h-2" />
        <p className="text-sm text-gray-500 text-right">Step {step} of {totalSteps}</p>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {step === 1 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-purple-800">Hair Type</h2>
              
              <FormField
                control={form.control}
                name="hairType"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>What is your hair type?</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="straight" />
                          </FormControl>
                          <FormLabel className="font-normal">Straight</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="wavy" />
                          </FormControl>
                          <FormLabel className="font-normal">Wavy</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="curly" />
                          </FormControl>
                          <FormLabel className="font-normal">Curly</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="coily" />
                          </FormControl>
                          <FormLabel className="font-normal">Coily</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="hairTexture"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>What is your hair texture?</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="fine" />
                          </FormControl>
                          <FormLabel className="font-normal">Fine</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="medium" />
                          </FormControl>
                          <FormLabel className="font-normal">Medium</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="thick" />
                          </FormControl>
                          <FormLabel className="font-normal">Thick</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}
          
          {step === 2 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-purple-800">Hair Concerns</h2>
              
              <FormField
                control={form.control}
                name="hairConcerns"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>What are your hair concerns? (Select all that apply)</FormLabel>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {["dryness", "frizz", "split_ends", "damage", "hair_loss", "lack_of_volume", "greasy_roots", "dandruff"].map((concern) => (
                        <FormItem
                          key={concern}
                          className="flex items-start space-x-2 space-y-0"
                        >
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(concern)}
                              onCheckedChange={(checked) => {
                                const updatedValue = checked
                                  ? [...field.value, concern]
                                  : field.value.filter((value) => value !== concern);
                                field.onChange(updatedValue);
                              }}
                            />
                          </FormControl>
                          <FormLabel className="font-normal text-sm leading-tight">
                            {concern.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                          </FormLabel>
                        </FormItem>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}
          
          {step === 3 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-purple-800">Scalp Condition</h2>
              
              <FormField
                control={form.control}
                name="scalpCondition"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>How would you describe your scalp condition?</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="dry" />
                          </FormControl>
                          <FormLabel className="font-normal">Dry</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="oily" />
                          </FormControl>
                          <FormLabel className="font-normal">Oily</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="combination" />
                          </FormControl>
                          <FormLabel className="font-normal">Combination</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="normal" />
                          </FormControl>
                          <FormLabel className="font-normal">Normal</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="sensitive" />
                          </FormControl>
                          <FormLabel className="font-normal">Sensitive/Itchy</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="washFrequency"
                render={({ field }) => (
                  <FormItem className="space-y-3">
                    <FormLabel>How often do you wash your hair?</FormLabel>
                    <FormControl>
                      <RadioGroup
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                        className="flex flex-col space-y-1"
                      >
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="daily" />
                          </FormControl>
                          <FormLabel className="font-normal">Daily</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="every_other_day" />
                          </FormControl>
                          <FormLabel className="font-normal">Every other day</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="twice_weekly" />
                          </FormControl>
                          <FormLabel className="font-normal">2-3 times a week</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="weekly" />
                          </FormControl>
                          <FormLabel className="font-normal">Once a week</FormLabel>
                        </FormItem>
                        <FormItem className="flex items-center space-x-3 space-y-0">
                          <FormControl>
                            <RadioGroupItem value="less_than_weekly" />
                          </FormControl>
                          <FormLabel className="font-normal">Less than once a week</FormLabel>
                        </FormItem>
                      </RadioGroup>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}
          
          {step === 4 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-purple-800">Hair Treatments</h2>
              
              <FormField
                control={form.control}
                name="hairTreatments"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>What hair treatments have you had? (Select all that apply)</FormLabel>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {["color", "bleach", "perm", "relaxer", "keratin", "extensions", "none"].map((treatment) => (
                        <FormItem
                          key={treatment}
                          className="flex items-start space-x-2 space-y-0"
                        >
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(treatment)}
                              onCheckedChange={(checked) => {
                                const updatedValue = checked
                                  ? [...(field.value || []), treatment]
                                  : (field.value || []).filter((value) => value !== treatment);
                                field.onChange(updatedValue);
                              }}
                            />
                          </FormControl>
                          <FormLabel className="font-normal text-sm leading-tight">
                            {treatment === "none" ? "None" : treatment.charAt(0).toUpperCase() + treatment.slice(1)}
                          </FormLabel>
                        </FormItem>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}
          
          {step === 5 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-purple-800">Hair Products</h2>
              
              <FormField
                control={form.control}
                name="hairProductsUsed"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>What hair products do you currently use? (Select all that apply)</FormLabel>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {["shampoo", "conditioner", "leave_in_conditioner", "hair_oil", "hair_mask", "heat_protectant", "styling_gel", "styling_mousse", "hair_spray"].map((product) => (
                        <FormItem
                          key={product}
                          className="flex items-start space-x-2 space-y-0"
                        >
                          <FormControl>
                            <Checkbox
                              checked={field.value?.includes(product)}
                              onCheckedChange={(checked) => {
                                const updatedValue = checked
                                  ? [...(field.value || []), product]
                                  : (field.value || []).filter((value) => value !== product);
                                field.onChange(updatedValue);
                              }}
                            />
                          </FormControl>
                          <FormLabel className="font-normal text-sm leading-tight">
                            {product.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                          </FormLabel>
                        </FormItem>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          )}
          
          <div className="flex justify-between pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={prevStep}
              disabled={step === 1}
            >
              Previous
            </Button>
            
            {step < totalSteps ? (
              <Button
                type="button"
                className="bg-purple-800 hover:bg-purple-900"
                onClick={nextStep}
              >
                Next
              </Button>
            ) : (
              <Button
                type="submit"
                className="bg-purple-800 hover:bg-purple-900"
              >
                Complete Quiz
              </Button>
            )}
          </div>
        </form>
      </Form>
    </div>
  );
}
