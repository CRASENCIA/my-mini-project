import { ReactNode } from "react";
import { BottomNav } from "@/components/navigation/BottomNav";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";

interface AppShellProps {
  children: ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const { user, isLoading } = useAuth();
  const [location, setLocation] = useLocation();

  // If not authenticated and not loading, redirect to login
  if (!user && !isLoading && !location.startsWith("/login") && !location.startsWith("/signup") && location !== "/") {
    setLocation("/login");
    return null;
  }

  return (
    <div className="flex flex-col min-h-screen max-w-md mx-auto">
      <main className="flex-1 pb-16">{children}</main>
      <BottomNav />
    </div>
  );
}
