import { Link, useLocation } from "wouter";
import { Calendar, Home, Leaf, Menu, User } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    {
      name: "Home",
      icon: Home,
      href: "/home",
      active: location === "/home",
    },
    {
      name: "Skincare",
      icon: Leaf,
      href: "/skincare",
      active: location.includes("/skincare"),
    },
    {
      name: "Haircare",
      icon: User,
      href: "/haircare",
      active: location.includes("/haircare"),
    },
    {
      name: "Health",
      icon: Menu,
      href: "/health",
      active: location === "/health",
    },
    {
      name: "Schedule",
      icon: Calendar,
      href: "/scheduler",
      active: location === "/scheduler",
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-gray-200 flex justify-around items-center px-4 max-w-md mx-auto">
      {navItems.map((item) => (
        <Link
          key={item.name}
          href={item.href}
          className={cn(
            "flex flex-col items-center justify-center w-full h-full",
            item.active ? "text-purple-800" : "text-gray-500"
          )}
        >
          <item.icon className={cn("h-5 w-5", item.active && "text-purple-800")} />
          <span className="text-xs mt-1">{item.name}</span>
        </Link>
      ))}
    </div>
  );
}
