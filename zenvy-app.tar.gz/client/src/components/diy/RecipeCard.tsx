import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DiyRecipe } from "@shared/schema";

interface RecipeCardProps {
  recipe: DiyRecipe;
  onSelect: (id: number) => void;
}

export function RecipeCard({ recipe, onSelect }: RecipeCardProps) {
  return (
    <Card className="overflow-hidden shadow-sm hover:shadow transition-shadow duration-300">
      <CardContent className="p-0">
        <div className="h-32 bg-gray-100 flex items-center justify-center">
          {recipe.imageUrl ? (
            <div className="w-full h-full flex items-center justify-center bg-gray-100 text-center p-4">
              <p className="text-sm font-medium">{recipe.name}</p>
            </div>
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-100 text-center p-4">
              <p className="text-sm font-medium">{recipe.name}</p>
            </div>
          )}
        </div>
        
        <div className="p-3">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-medium text-purple-900">{recipe.name}</h3>
            <span className="text-xs px-2 py-0.5 bg-purple-100 text-purple-800 rounded-full">
              {recipe.category}
            </span>
          </div>
          
          <p className="text-sm text-gray-600 mb-3 line-clamp-2">{recipe.description}</p>
          
          <div className="mb-3">
            <p className="text-xs text-gray-500 uppercase tracking-wide mb-1">Good for:</p>
            <div className="flex flex-wrap gap-1">
              {recipe.forSkinType && recipe.forSkinType.map((type, index) => (
                <span key={index} className="text-xs px-2 py-0.5 bg-gray-100 text-gray-700 rounded-full">
                  {type}
                </span>
              ))}
              {recipe.forHairType && recipe.forHairType.map((type, index) => (
                <span key={index} className="text-xs px-2 py-0.5 bg-gray-100 text-gray-700 rounded-full">
                  {type}
                </span>
              ))}
            </div>
          </div>
          
          <Button 
            className="w-full bg-purple-800 hover:bg-purple-900 text-white"
            onClick={() => onSelect(recipe.id)}
          >
            View Recipe
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
