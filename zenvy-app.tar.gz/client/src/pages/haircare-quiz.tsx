import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AppShell } from "@/components/layout/AppShell";
import { HairQuizForm } from "@/components/forms/HairQuizForm";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function HaircareQuiz() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [_, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Generate routine based on quiz results
  const createRoutine = useMutation({
    mutationFn: async (data: any) => {
      setIsSubmitting(true);
      try {
        // Generate daily routine
        const dailyRoutineSteps = generateHaircareSteps(data, "daily");
        const dailyRoutineResponse = await apiRequest("POST", "/api/haircare-routines", {
          userId: user?.id,
          name: "Daily Hair Care",
          description: `Personalized daily routine for ${data.hairType} hair`,
          frequency: "daily",
          steps: dailyRoutineSteps,
        });
        const dailyRoutine = await dailyRoutineResponse.json();
        
        // Generate weekly routine
        const weeklyRoutineSteps = generateHaircareSteps(data, "weekly");
        const weeklyRoutineResponse = await apiRequest("POST", "/api/haircare-routines", {
          userId: user?.id,
          name: "Weekly Hair Treatment",
          description: `Weekly treatment for ${data.hairType} hair`,
          frequency: "weekly",
          steps: weeklyRoutineSteps,
        });
        const weeklyRoutine = await weeklyRoutineResponse.json();
        
        // Generate monthly routine
        const monthlyRoutineSteps = generateHaircareSteps(data, "monthly");
        const monthlyRoutineResponse = await apiRequest("POST", "/api/haircare-routines", {
          userId: user?.id,
          name: "Monthly Deep Conditioning",
          description: `Monthly deep conditioning for ${data.hairType} hair`,
          frequency: "monthly",
          steps: monthlyRoutineSteps,
        });
        const monthlyRoutine = await monthlyRoutineResponse.json();
        
        return {
          dailyRoutine,
          weeklyRoutine,
          monthlyRoutine
        };
      } finally {
        setIsSubmitting(false);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/haircare-routines"] });
      toast({
        title: "Haircare routines created",
        description: "Your personalized haircare routines have been created successfully",
      });
      setLocation("/haircare");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create haircare routines",
        variant: "destructive",
      });
    }
  });
  
  const handleQuizComplete = (data: any) => {
    // Update user profile if needed
    if (user?.id) {
      // Create haircare routines
      createRoutine.mutate(data);
    } else {
      toast({
        title: "Error",
        description: "You must be logged in to create haircare routines",
        variant: "destructive",
      });
    }
  };
  
  // Generate haircare steps based on hair type and quiz results
  const generateHaircareSteps = (data: any, frequency: string) => {
    const { hairType, hairTexture, hairConcerns, scalpCondition } = data;
    const steps = [];
    
    // Common steps for all routines
    if (frequency === "daily") {
      // Daily routine steps
      if (data.washFrequency === "daily" || data.washFrequency === "every_other_day") {
        // Add shampoo step if they wash frequently
        steps.push({
          order: 1,
          product: "Gentle Shampoo",
          description: scalpCondition === "oily" 
            ? "Clarifying shampoo for oily scalp" 
            : scalpCondition === "dry" 
            ? "Moisturizing shampoo for dry scalp" 
            : "Gentle, pH-balanced shampoo",
        });
        
        // Add conditioner
        steps.push({
          order: 2,
          product: "Conditioner",
          description: hairType === "curly" || hairType === "coily" 
            ? "Rich, moisturizing conditioner" 
            : hairType === "straight" && hairTexture === "fine" 
            ? "Lightweight volumizing conditioner" 
            : "Balanced conditioner for your hair type",
        });
      }
      
      // Add leave-in product
      if (hairType === "curly" || hairType === "coily" || hairConcerns.includes("frizz") || hairConcerns.includes("dryness")) {
        steps.push({
          order: 3,
          product: "Leave-in Conditioner",
          description: "Lightweight leave-in conditioner to add moisture",
        });
      }
      
      // Add styling product based on hair type
      if (hairType === "straight") {
        if (hairTexture === "fine") {
          steps.push({
            order: 4,
            product: "Volumizing Spray",
            description: "Lightweight spray to add volume at the roots",
          });
        } else {
          steps.push({
            order: 4,
            product: "Smoothing Serum",
            description: "Anti-frizz serum for smooth finish",
          });
        }
      } else if (hairType === "wavy") {
        steps.push({
          order: 4,
          product: "Wave Enhancing Mousse",
          description: "Lightweight mousse to enhance natural waves",
        });
      } else if (hairType === "curly" || hairType === "coily") {
        steps.push({
          order: 4,
          product: "Curl Defining Cream",
          description: "Moisturizing cream to define and hold curls",
        });
      }
    } else if (frequency === "weekly") {
      // Weekly routine steps
      steps.push({
        order: 1,
        product: "Clarifying Shampoo",
        description: "Deep cleansing shampoo to remove buildup (use once a week)",
      });
      
      // Add treatment based on concerns
      if (hairConcerns.includes("damage") || hairConcerns.includes("split_ends")) {
        steps.push({
          order: 2,
          product: "Protein Treatment",
          description: "Strengthening protein treatment to repair damage",
        });
      } else if (hairConcerns.includes("dryness") || hairConcerns.includes("frizz")) {
        steps.push({
          order: 2,
          product: "Deep Conditioning Mask",
          description: "Intense moisturizing treatment to hydrate hair",
        });
      } else if (scalpCondition === "oily" || scalpCondition === "dandruff") {
        steps.push({
          order: 2,
          product: "Scalp Treatment",
          description: "Balancing treatment to address scalp concerns",
        });
      } else {
        steps.push({
          order: 2,
          product: "Hair Mask",
          description: "Nourishing mask suited for your hair type",
        });
      }
      
      // Add final step
      steps.push({
        order: 3,
        product: "Conditioner",
        description: "Regular conditioner to seal cuticles after treatment",
      });
    } else if (frequency === "monthly") {
      // Monthly routine steps
      steps.push({
        order: 1,
        product: "Scalp Scrub",
        description: "Exfoliating scrub to remove dead skin cells",
      });
      
      steps.push({
        order: 2,
        product: "Clarifying Shampoo",
        description: "Deep cleansing to reset hair and scalp",
      });
      
      steps.push({
        order: 3,
        product: "Intensive Treatment",
        description: hairConcerns.includes("damage") 
          ? "Bond-repairing deep treatment"
          : "Deep conditioning intensive mask",
      });
      
      // Add final step
      steps.push({
        order: 4,
        product: "Hair Oil Treatment",
        description: "Nourishing oil treatment to seal and protect ends",
      });
    }
    
    return steps;
  };
  
  return (
    <AppShell>
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold text-purple-800">Haircare Quiz</h1>
        <p className="text-gray-600">
          Answer a few questions to help us create a personalized haircare routine for you.
        </p>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Let's understand your hair</CardTitle>
          </CardHeader>
          <CardContent>
            <HairQuizForm onComplete={handleQuizComplete} />
          </CardContent>
        </Card>
        
        {isSubmitting && (
          <div className="mt-6 text-center p-4 bg-purple-50 rounded-lg">
            <p className="text-purple-800 font-medium">Creating your personalized haircare routines...</p>
            <p className="text-sm text-purple-600 mt-1">This may take a moment</p>
          </div>
        )}
      </div>
    </AppShell>
  );
}
