import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CalendarIcon, Check, Plus, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { AppShell } from "@/components/layout/AppShell";
import { Schedule } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { ScheduleItem } from "@/components/scheduler/ScheduleItem";

// Form schema
const scheduleFormSchema = z.object({
  title: z.string().min(2, "Title must be at least 2 characters"),
  description: z.string().optional(),
  type: z.string().min(1, "Please select a type"),
  startTime: z.date(),
  routineId: z.number().optional(),
});

type ScheduleFormValues = z.infer<typeof scheduleFormSchema>;

export default function Scheduler() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [showDialog, setShowDialog] = useState(false);
  
  // Format date for API query
  const formattedDate = date ? format(date, "yyyy-MM-dd") : format(new Date(), "yyyy-MM-dd");
  
  // Fetch schedules for selected date
  const { data: schedules, isLoading } = useQuery<Schedule[]>({ 
    queryKey: [`/api/schedules?date=${formattedDate}`],
    enabled: !!user,
  });
  
  // Schedule creation mutation
  const createSchedule = useMutation({
    mutationFn: async (data: any) => {
      return apiRequest("POST", "/api/schedules", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/schedules?date=${formattedDate}`] });
      setShowDialog(false);
      toast({
        title: "Schedule created",
        description: "Your schedule has been added successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create schedule",
        variant: "destructive",
      });
    }
  });
  
  // Complete schedule mutation
  const completeSchedule = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("PUT", `/api/schedules/${id}/complete`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/schedules?date=${formattedDate}`] });
      toast({
        title: "Schedule completed",
        description: "Schedule marked as completed",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update schedule",
        variant: "destructive",
      });
    }
  });
  
  // Delete schedule mutation
  const deleteSchedule = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/schedules/${id}`, null);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/schedules?date=${formattedDate}`] });
      toast({
        title: "Schedule deleted",
        description: "Your schedule has been removed",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete schedule",
        variant: "destructive",
      });
    }
  });
  
  // Form for creating new schedule
  const form = useForm<ScheduleFormValues>({
    resolver: zodResolver(scheduleFormSchema),
    defaultValues: {
      title: "",
      description: "",
      type: "",
      startTime: new Date(),
    },
  });
  
  const onSubmit = (values: ScheduleFormValues) => {
    const startDate = new Date(values.startTime);
    
    // Combine selected date with time from form
    if (date) {
      startDate.setFullYear(date.getFullYear(), date.getMonth(), date.getDate());
    }
    
    const scheduleData = {
      ...values,
      startTime: startDate.toISOString(),
      endTime: new Date(startDate.getTime() + 30 * 60000).toISOString(), // Default to 30 min
    };
    
    createSchedule.mutate(scheduleData);
  };
  
  const handleMarkComplete = (id: number) => {
    completeSchedule.mutate(id);
  };
  
  const handleDelete = (id: number) => {
    deleteSchedule.mutate(id);
  };
  
  // Group schedules by time period
  const morningSchedules = schedules?.filter(s => {
    const hour = new Date(s.startTime).getHours();
    return hour >= 5 && hour < 12;
  }) || [];
  
  const afternoonSchedules = schedules?.filter(s => {
    const hour = new Date(s.startTime).getHours();
    return hour >= 12 && hour < 18;
  }) || [];
  
  const eveningSchedules = schedules?.filter(s => {
    const hour = new Date(s.startTime).getHours();
    return hour >= 18 || hour < 5;
  }) || [];

  return (
    <AppShell>
      <div className="p-4 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-purple-800">Scheduler</h1>
          <Button 
            className="bg-purple-800 hover:bg-purple-900 text-white"
            onClick={() => setShowDialog(true)}
          >
            <Plus className="h-4 w-4 mr-1" /> Add Activity
          </Button>
        </div>
        
        {/* Date Picker */}
        <div className="flex justify-center mb-4">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "justify-start text-left font-normal w-full max-w-xs",
                  !date && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, "PPP") : <span>Pick a date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>
        
        {isLoading ? (
          <div className="text-center py-10">
            <p className="text-gray-500">Loading your schedules...</p>
          </div>
        ) : (
          <>
            {/* Morning Schedule */}
            <div className="space-y-3">
              <h2 className="text-lg font-medium text-gray-800">Morning</h2>
              {morningSchedules.length > 0 ? (
                <div className="space-y-2">
                  {morningSchedules.map(schedule => (
                    <ScheduleItem 
                      key={schedule.id} 
                      schedule={schedule} 
                      onComplete={handleMarkComplete}
                      onDelete={handleDelete}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 bg-gray-50 rounded-lg">
                  <p className="text-gray-500 text-sm">No morning activities scheduled</p>
                </div>
              )}
            </div>
            
            {/* Afternoon Schedule */}
            <div className="space-y-3">
              <h2 className="text-lg font-medium text-gray-800">Afternoon</h2>
              {afternoonSchedules.length > 0 ? (
                <div className="space-y-2">
                  {afternoonSchedules.map(schedule => (
                    <ScheduleItem 
                      key={schedule.id} 
                      schedule={schedule} 
                      onComplete={handleMarkComplete}
                      onDelete={handleDelete}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 bg-gray-50 rounded-lg">
                  <p className="text-gray-500 text-sm">No afternoon activities scheduled</p>
                </div>
              )}
            </div>
            
            {/* Evening Schedule */}
            <div className="space-y-3">
              <h2 className="text-lg font-medium text-gray-800">Evening</h2>
              {eveningSchedules.length > 0 ? (
                <div className="space-y-2">
                  {eveningSchedules.map(schedule => (
                    <ScheduleItem 
                      key={schedule.id} 
                      schedule={schedule} 
                      onComplete={handleMarkComplete}
                      onDelete={handleDelete}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 bg-gray-50 rounded-lg">
                  <p className="text-gray-500 text-sm">No evening activities scheduled</p>
                </div>
              )}
            </div>
          </>
        )}
      </div>
      
      {/* Add Schedule Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add New Activity</DialogTitle>
            <DialogDescription>
              Schedule a new self-care activity for {date ? format(date, "MMMM d, yyyy") : "today"}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Activity title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (optional)</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Add details about this activity" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Activity Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select activity type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="skincare">Skincare</SelectItem>
                        <SelectItem value="haircare">Haircare</SelectItem>
                        <SelectItem value="health">Health</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="startTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time</FormLabel>
                    <FormControl>
                      <Input type="time" {...field} value={format(field.value, "HH:mm")} onChange={(e) => {
                        const [hours, minutes] = e.target.value.split(':');
                        const date = new Date();
                        date.setHours(parseInt(hours));
                        date.setMinutes(parseInt(minutes));
                        field.onChange(date);
                      }} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowDialog(false)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="bg-purple-800 hover:bg-purple-900"
                  disabled={createSchedule.isPending}
                >
                  {createSchedule.isPending ? "Saving..." : "Add Activity"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
