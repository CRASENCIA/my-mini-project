import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useEffect, useState } from "react";

export default function Welcome() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const slides = [
    {
      title: "Welcome to Zenvy",
      description: "Your personalized self-care journey begins here.",
      btnText: "Next",
    },
    {
      title: "Smart Routines",
      description: "Discover personalized skincare and haircare routines based on your unique needs.",
      btnText: "Next",
    },
    {
      title: "Health Tracking",
      description: "Monitor your health metrics and progress towards your goals.",
      btnText: "Next",
    },
    {
      title: "Ready to Begin?",
      description: "Let's start your self-care journey with Zenvy.",
      btnText: "Get Started",
    },
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white flex flex-col justify-between">
      <div className="flex flex-col items-center justify-center pt-10 px-6">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-purple-800 mb-2">ZENVY</h1>
          <p className="text-sm text-purple-600">
            "Only as we take care of ourselves can we take care of others"
          </p>
        </div>

        <div className="w-full max-w-md rounded-2xl overflow-hidden shadow-lg mb-8">
          <div className="bg-white p-8 text-center">
            <h2 className="text-2xl font-bold text-purple-800 mb-4">{slides[currentSlide].title}</h2>
            <p className="text-gray-600 mb-6">{slides[currentSlide].description}</p>
            
            {currentSlide === slides.length - 1 ? (
              <Link href="/login">
                <Button className="bg-purple-800 hover:bg-purple-900 text-white px-8 py-2 rounded-full">
                  {slides[currentSlide].btnText}
                </Button>
              </Link>
            ) : (
              <Button 
                className="bg-purple-800 hover:bg-purple-900 text-white px-8 py-2 rounded-full"
                onClick={handleNext}
              >
                {slides[currentSlide].btnText}
              </Button>
            )}
          </div>
        </div>

        <div className="flex justify-center space-x-2 mb-6">
          {slides.map((_, index) => (
            <div 
              key={index} 
              className={`h-2 w-2 rounded-full ${
                index === currentSlide ? "bg-purple-800" : "bg-gray-300"
              }`}
            />
          ))}
        </div>
      </div>

      <div className="flex justify-center items-center space-x-4 py-4">
        {currentSlide < slides.length - 1 ? (
          <>
            <Link href="/login">
              <Button variant="outline" className="text-purple-800 border-purple-800">
                Skip
              </Button>
            </Link>
          </>
        ) : (
          <div className="flex justify-center space-x-4">
            <Link href="/login">
              <Button variant="outline" className="text-purple-800 border-purple-800">
                Login
              </Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-purple-800 hover:bg-purple-900 text-white">
                Sign Up
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
