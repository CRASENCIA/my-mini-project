import { useQuery } from "@tanstack/react-query";
import { ChevronRight, Plus } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AppShell } from "@/components/layout/AppShell";
import { SkincareCard } from "@/components/skincare/SkincareCard";
import { SkincareRoutine } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";

export default function Skincare() {
  const { user } = useAuth();
  
  const { data: routines, isLoading } = useQuery<SkincareRoutine[]>({ 
    queryKey: ["/api/skincare-routines"],
    enabled: !!user,
  });
  
  // Filter routines by time of day
  const morningRoutines = routines?.filter(routine => routine.timeOfDay === "morning") || [];
  const eveningRoutines = routines?.filter(routine => routine.timeOfDay === "evening") || [];
  const weeklyRoutines = routines?.filter(routine => routine.timeOfDay === "weekly") || [];

  return (
    <AppShell>
      <div className="p-4 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-purple-800">Skincare</h1>
          <Link href="/skincare-quiz">
            <Button className="bg-purple-800 hover:bg-purple-900 text-white">
              <Plus className="h-4 w-4 mr-1" /> New Routine
            </Button>
          </Link>
        </div>
        
        <Card className="bg-gradient-to-r from-purple-500 to-purple-700 text-white overflow-hidden">
          <CardContent className="p-6">
            <div className="flex flex-col space-y-2">
              <h3 className="text-lg font-semibold">Personalized For You</h3>
              <p className="text-sm opacity-90">
                Discover routines tailored to your {user?.profile?.skinType || "skin"} type
              </p>
              <Link href="/skincare-quiz">
                <Button variant="secondary" className="mt-2 w-full bg-white text-purple-700 hover:bg-gray-100">
                  Take Skin Quiz
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        <Tabs defaultValue="morning" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="morning">Morning</TabsTrigger>
            <TabsTrigger value="evening">Evening</TabsTrigger>
            <TabsTrigger value="weekly">Weekly</TabsTrigger>
          </TabsList>
          
          <TabsContent value="morning" className="space-y-4 mt-4">
            {isLoading ? (
              <p className="text-center py-6 text-sm text-gray-500">Loading routines...</p>
            ) : morningRoutines.length > 0 ? (
              <div className="space-y-3">
                {morningRoutines.map(routine => (
                  <SkincareCard key={routine.id} routine={routine} />
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">No morning routines yet</p>
                <Link href="/skincare-quiz">
                  <Button className="bg-purple-800 hover:bg-purple-900 text-white">
                    Create Morning Routine
                  </Button>
                </Link>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="evening" className="space-y-4 mt-4">
            {isLoading ? (
              <p className="text-center py-6 text-sm text-gray-500">Loading routines...</p>
            ) : eveningRoutines.length > 0 ? (
              <div className="space-y-3">
                {eveningRoutines.map(routine => (
                  <SkincareCard key={routine.id} routine={routine} />
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">No evening routines yet</p>
                <Link href="/skincare-quiz">
                  <Button className="bg-purple-800 hover:bg-purple-900 text-white">
                    Create Evening Routine
                  </Button>
                </Link>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="weekly" className="space-y-4 mt-4">
            {isLoading ? (
              <p className="text-center py-6 text-sm text-gray-500">Loading routines...</p>
            ) : weeklyRoutines.length > 0 ? (
              <div className="space-y-3">
                {weeklyRoutines.map(routine => (
                  <SkincareCard key={routine.id} routine={routine} />
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500 mb-4">No weekly routines yet</p>
                <Link href="/skincare-quiz">
                  <Button className="bg-purple-800 hover:bg-purple-900 text-white">
                    Create Weekly Routine
                  </Button>
                </Link>
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        {/* Tips Section */}
        <div className="space-y-3">
          <h2 className="text-lg font-semibold text-gray-800">Skincare Tips</h2>
          <Card>
            <CardContent className="p-4">
              <h3 className="font-medium mb-2">Daily Sunscreen</h3>
              <p className="text-sm text-gray-600">
                Apply SPF every morning, even on cloudy days or when staying indoors.
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <h3 className="font-medium mb-2">Layering Products</h3>
              <p className="text-sm text-gray-600">
                Apply products from thinnest to thickest consistency for maximum absorption.
              </p>
            </CardContent>
          </Card>
        </div>
        
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-800">DIY Remedies</h2>
          <Link href="/diy">
            <Button variant="ghost" size="sm" className="text-purple-700">
              View All
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-2 gap-3">
          <Card className="overflow-hidden">
            <CardContent className="p-0">
              <div className="bg-gray-100 h-24 flex items-center justify-center">
                <div className="text-center">
                  <p className="text-sm font-medium">Honey Mask</p>
                  <p className="text-xs text-gray-500">For Dry Skin</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="overflow-hidden">
            <CardContent className="p-0">
              <div className="bg-gray-100 h-24 flex items-center justify-center">
                <div className="text-center">
                  <p className="text-sm font-medium">Clay Mask</p>
                  <p className="text-xs text-gray-500">For Oily Skin</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
