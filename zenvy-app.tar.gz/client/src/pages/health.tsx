import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ActivitySquare, ChevronRight, Plus, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { HealthLog } from "@shared/schema";
import { AppShell } from "@/components/layout/AppShell";
import { BMICalculator } from "@/components/health/BMICalculator";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Health() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [showBMICalculator, setShowBMICalculator] = useState(false);
  
  // Fetch latest health log
  const { data: latestLog, isLoading } = useQuery<HealthLog>({ 
    queryKey: ["/api/health-logs/latest"],
    enabled: !!user,
  });
  
  // Fetch health logs history
  const { data: healthLogs } = useQuery<HealthLog[]>({ 
    queryKey: ["/api/health-logs"],
    enabled: !!user,
  });
  
  // Create new health log mutation
  const createHealthLog = useMutation({
    mutationFn: async (data: Partial<HealthLog>) => {
      return apiRequest("POST", "/api/health-logs", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/health-logs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/health-logs/latest"] });
      setShowBMICalculator(false);
      toast({
        title: "Health log saved",
        description: "Your health data has been successfully saved",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save health log",
        variant: "destructive",
      });
    }
  });
  
  // Calculate BMI
  const calculateBMI = (weight: number, height: number): string => {
    const heightInMeters = height / 100;
    const bmi = weight / (heightInMeters * heightInMeters);
    return bmi.toFixed(1);
  };
  
  // Get BMI category
  const getBMICategory = (bmi: number): string => {
    if (bmi < 18.5) return "Underweight";
    if (bmi < 25) return "Normal weight";
    if (bmi < 30) return "Overweight";
    return "Obese";
  };
  
  // Handle save BMI data
  const handleSaveBMI = (weight: number, height: number) => {
    const bmi = calculateBMI(weight, height);
    
    createHealthLog.mutate({
      userId: user?.id,
      weight,
      height,
      bmi,
      logDate: new Date().toISOString(),
    });
  };

  return (
    <AppShell>
      <div className="p-4 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-purple-800">Health Tracker</h1>
          <Button 
            className="bg-purple-800 hover:bg-purple-900 text-white"
            onClick={() => setShowBMICalculator(true)}
          >
            <Plus className="h-4 w-4 mr-1" /> Log Health
          </Button>
        </div>
        
        {showBMICalculator ? (
          <BMICalculator 
            onCancel={() => setShowBMICalculator(false)}
            onSave={handleSaveBMI}
            initialWeight={latestLog?.weight}
            initialHeight={latestLog?.height}
            isLoading={createHealthLog.isPending}
          />
        ) : (
          <>
            {/* Current Health Status */}
            <Card className="bg-gradient-to-r from-purple-500 to-purple-700 text-white">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Current Health Status</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <p className="text-center py-2">Loading your health data...</p>
                ) : latestLog ? (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-sm opacity-80">BMI</p>
                        <h2 className="text-3xl font-bold">{latestLog.bmi}</h2>
                        <p className="text-sm">{getBMICategory(parseFloat(latestLog.bmi))}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm opacity-80">Last updated</p>
                        <p className="text-sm">
                          {new Date(latestLog.logDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4 pt-2">
                      <div className="bg-white/10 p-2 rounded">
                        <p className="text-xs opacity-80">Weight</p>
                        <p className="text-xl font-semibold">{latestLog.weight} kg</p>
                      </div>
                      <div className="bg-white/10 p-2 rounded">
                        <p className="text-xs opacity-80">Height</p>
                        <p className="text-xl font-semibold">{latestLog.height} cm</p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p>No health data available</p>
                    <Button
                      variant="secondary"
                      className="mt-2 bg-white text-purple-700 hover:bg-gray-100"
                      onClick={() => setShowBMICalculator(true)}
                    >
                      Calculate BMI
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
            
            {/* Health Insights */}
            {latestLog && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Health Insights</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="font-medium">BMI Analysis</h3>
                    <p className="text-sm text-gray-600">
                      {parseFloat(latestLog.bmi) < 18.5 && "You're currently underweight. Consider increasing your caloric intake with nutrient-dense foods."}
                      {parseFloat(latestLog.bmi) >= 18.5 && parseFloat(latestLog.bmi) < 25 && "You're at a healthy weight. Maintain your balanced diet and regular physical activity."}
                      {parseFloat(latestLog.bmi) >= 25 && parseFloat(latestLog.bmi) < 30 && "You're slightly overweight. Consider moderating your diet and increasing physical activity."}
                      {parseFloat(latestLog.bmi) >= 30 && "Your BMI indicates obesity. Consider consulting a healthcare professional for a personalized plan."}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="font-medium">Recommendations</h3>
                    <ul className="text-sm text-gray-600 space-y-1">
                      <li>• Drink at least 8 glasses of water daily</li>
                      <li>• Aim for 7-9 hours of quality sleep</li>
                      <li>• Include 30 minutes of moderate exercise daily</li>
                      <li>• Incorporate more vegetables and fruits in your diet</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* Progress Tracking */}
            {healthLogs && healthLogs.length > 1 && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Progress Tracking</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <p className="text-sm">Weight History</p>
                      <TrendingUp className="h-4 w-4 text-purple-700" />
                    </div>
                    
                    <div className="space-y-2">
                      {healthLogs.slice(0, 5).map((log, index) => (
                        <div key={log.id} className="flex items-center justify-between">
                          <p className="text-sm text-gray-600">
                            {new Date(log.logDate).toLocaleDateString()}
                          </p>
                          <p className={`text-sm font-medium ${
                            index > 0 && log.weight < healthLogs[index - 1].weight
                              ? "text-green-600"
                              : index > 0 && log.weight > healthLogs[index - 1].weight
                              ? "text-red-600"
                              : "text-gray-600"
                          }`}>
                            {log.weight} kg
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* Health Tips */}
            <div className="space-y-3">
              <h2 className="text-lg font-semibold text-gray-800">Health Tips</h2>
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2">Morning Hydration</h3>
                  <p className="text-sm text-gray-600">
                    Drink a glass of water first thing in the morning to boost metabolism and rehydrate.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2">Digital Detox</h3>
                  <p className="text-sm text-gray-600">
                    Take regular breaks from screens to reduce eye strain and improve mental health.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-medium mb-2">Mindful Eating</h3>
                  <p className="text-sm text-gray-600">
                    Eat slowly and without distractions to better recognize hunger cues and enjoy food.
                  </p>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>
    </AppShell>
  );
}
