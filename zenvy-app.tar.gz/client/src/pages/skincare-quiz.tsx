import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AppShell } from "@/components/layout/AppShell";
import { SkinQuizForm } from "@/components/forms/SkinQuizForm";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function SkincareQuiz() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [_, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Generate routine based on quiz results
  const createRoutine = useMutation({
    mutationFn: async (data: any) => {
      setIsSubmitting(true);
      try {
        // Generate morning routine
        const morningRoutineSteps = generateSkincareSteps(data, "morning");
        const morningRoutineResponse = await apiRequest("POST", "/api/skincare-routines", {
          userId: user?.id,
          name: "Morning Routine",
          description: `Personalized morning routine for ${data.skinType} skin`,
          timeOfDay: "morning",
          steps: morningRoutineSteps,
        });
        const morningRoutine = await morningRoutineResponse.json();
        
        // Generate evening routine
        const eveningRoutineSteps = generateSkincareSteps(data, "evening");
        const eveningRoutineResponse = await apiRequest("POST", "/api/skincare-routines", {
          userId: user?.id,
          name: "Evening Routine",
          description: `Personalized evening routine for ${data.skinType} skin`,
          timeOfDay: "evening",
          steps: eveningRoutineSteps,
        });
        const eveningRoutine = await eveningRoutineResponse.json();
        
        // Generate weekly routine
        const weeklyRoutineSteps = generateSkincareSteps(data, "weekly");
        const weeklyRoutineResponse = await apiRequest("POST", "/api/skincare-routines", {
          userId: user?.id,
          name: "Weekly Treatment",
          description: `Weekly treatment for ${data.skinType} skin`,
          timeOfDay: "weekly",
          steps: weeklyRoutineSteps,
        });
        const weeklyRoutine = await weeklyRoutineResponse.json();
        
        return {
          morningRoutine,
          eveningRoutine,
          weeklyRoutine
        };
      } finally {
        setIsSubmitting(false);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/skincare-routines"] });
      toast({
        title: "Skincare routines created",
        description: "Your personalized skincare routines have been created successfully",
      });
      setLocation("/skincare");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create skincare routines",
        variant: "destructive",
      });
    }
  });
  
  const handleQuizComplete = (data: any) => {
    // Update user profile if needed
    if (user?.id) {
      // Create skincare routines
      createRoutine.mutate(data);
    } else {
      toast({
        title: "Error",
        description: "You must be logged in to create skincare routines",
        variant: "destructive",
      });
    }
  };
  
  // Generate skincare steps based on skin type and quiz results
  const generateSkincareSteps = (data: any, timeOfDay: string) => {
    const { skinType, skinConcerns, skinSensitivity } = data;
    const steps = [];
    
    // Common steps for all routines
    if (timeOfDay === "morning" || timeOfDay === "evening") {
      steps.push({
        order: 1,
        product: "Cleanser",
        description: skinType === "oily" 
          ? "Foaming cleanser to remove excess oil" 
          : skinType === "dry" 
          ? "Creamy, hydrating cleanser" 
          : "Gentle, balanced cleanser",
      });
    }
    
    // Morning specific steps
    if (timeOfDay === "morning") {
      // Add toner
      steps.push({
        order: 2,
        product: "Toner",
        description: skinType === "oily" 
          ? "Balancing toner with niacinamide" 
          : "Hydrating toner with hyaluronic acid",
      });
      
      // Add serum based on concerns
      if (skinConcerns.includes("acne") || skinConcerns.includes("oiliness")) {
        steps.push({
          order: 3,
          product: "Serum",
          description: "Vitamin C serum for brightening and antioxidant protection",
        });
      } else if (skinConcerns.includes("aging") || skinConcerns.includes("dullness")) {
        steps.push({
          order: 3,
          product: "Serum",
          description: "Antioxidant serum with vitamin C and ferulic acid",
        });
      } else {
        steps.push({
          order: 3,
          product: "Serum",
          description: "Hydrating serum with hyaluronic acid",
        });
      }
      
      // Add moisturizer
      steps.push({
        order: 4,
        product: "Moisturizer",
        description: skinType === "oily" 
          ? "Oil-free gel moisturizer" 
          : skinType === "dry" 
          ? "Rich, creamy moisturizer" 
          : "Lightweight, balanced moisturizer",
      });
      
      // Add sunscreen
      steps.push({
        order: 5,
        product: "Sunscreen",
        description: "Broad-spectrum SPF 30+ sunscreen",
      });
    }
    
    // Evening specific steps
    if (timeOfDay === "evening") {
      // Add double cleanse for evening
      steps.push({
        order: 2,
        product: "Second Cleanse",
        description: "Gentle second cleanse to remove remaining impurities",
      });
      
      // Add treatment based on concerns
      if (skinConcerns.includes("acne")) {
        steps.push({
          order: 3,
          product: "Treatment",
          description: skinSensitivity === "very_sensitive" 
            ? "Gentle salicylic acid treatment" 
            : "Benzoyl peroxide or salicylic acid treatment",
        });
      } else if (skinConcerns.includes("aging")) {
        steps.push({
          order: 3,
          product: "Treatment",
          description: skinSensitivity === "very_sensitive" 
            ? "Gentle retinol alternative" 
            : "Retinol serum",
        });
      }
      
      // Add moisturizer
      steps.push({
        order: 4,
        product: "Moisturizer",
        description: "Nourishing night moisturizer",
      });
      
      // Add optional face oil for dry skin
      if (skinType === "dry") {
        steps.push({
          order: 5,
          product: "Face Oil",
          description: "Nourishing facial oil with squalane or jojoba",
        });
      }
    }
    
    // Weekly specific steps
    if (timeOfDay === "weekly") {
      steps.push({
        order: 1,
        product: "Cleanser",
        description: "Gentle cleanser to prepare skin",
      });
      
      // Add exfoliant based on skin type
      steps.push({
        order: 2,
        product: "Exfoliant",
        description: skinType === "oily" 
          ? "Chemical exfoliant with BHA" 
          : skinType === "dry" 
          ? "Gentle AHA exfoliant" 
          : "Balanced AHA/BHA exfoliant",
      });
      
      // Add mask based on concerns
      if (skinConcerns.includes("acne") || skinConcerns.includes("oiliness")) {
        steps.push({
          order: 3,
          product: "Mask",
          description: "Clay mask to absorb excess oil and purify pores",
        });
      } else if (skinConcerns.includes("dryness")) {
        steps.push({
          order: 3,
          product: "Mask",
          description: "Hydrating sheet mask with hyaluronic acid",
        });
      } else if (skinConcerns.includes("dullness") || skinConcerns.includes("uneven tone")) {
        steps.push({
          order: 3,
          product: "Mask",
          description: "Brightening mask with vitamin C or niacinamide",
        });
      }
      
      // Add final moisturizer
      steps.push({
        order: 4,
        product: "Moisturizer",
        description: "Rich moisturizer to restore skin barrier",
      });
    }
    
    return steps;
  };
  
  return (
    <AppShell>
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold text-purple-800">Skincare Quiz</h1>
        <p className="text-gray-600">
          Answer a few questions to help us create a personalized skincare routine for you.
        </p>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Let's understand your skin</CardTitle>
          </CardHeader>
          <CardContent>
            <SkinQuizForm onComplete={handleQuizComplete} />
          </CardContent>
        </Card>
        
        {isSubmitting && (
          <div className="mt-6 text-center p-4 bg-purple-50 rounded-lg">
            <p className="text-purple-800 font-medium">Creating your personalized skincare routines...</p>
            <p className="text-sm text-purple-600 mt-1">This may take a moment</p>
          </div>
        )}
      </div>
    </AppShell>
  );
}
