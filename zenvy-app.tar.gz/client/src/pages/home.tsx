import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Calendar, Clock, Heart, Menu, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { AppShell } from "@/components/layout/AppShell";
import { Schedule } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

export default function Home() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [greeting, setGreeting] = useState("Good day");
  
  // Calculate greeting based on time of day
  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) setGreeting("Good morning");
    else if (hour < 18) setGreeting("Good afternoon");
    else setGreeting("Good evening");
  }, []);
  
  // Fetch upcoming schedules
  const { data: schedules, isLoading } = useQuery<Schedule[]>({ 
    queryKey: ["/api/schedules?upcoming=true"],
    enabled: !!user,
  });
  
  // Group schedules by type
  const skincareSchedules = schedules?.filter(s => s.type === "skincare") || [];
  const haircareSchedules = schedules?.filter(s => s.type === "haircare") || [];
  const healthSchedules = schedules?.filter(s => s.type === "health") || [];
  
  // Get the next upcoming schedule
  const allSchedules = schedules || [];
  const nextSchedule = allSchedules.length > 0 ? allSchedules[0] : null;
  
  // Format time from date
  const formatTime = (date: string) => {
    return new Date(date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };
  
  // Format relative time
  const getRelativeTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = date.getTime() - now.getTime();
    const diffMins = Math.round(diffMs / 60000);
    
    if (diffMins < 0) return "Overdue";
    if (diffMins < 60) return `In ${diffMins} mins`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `In ${diffHours} hrs`;
    
    const diffDays = Math.floor(diffHours / 24);
    return `In ${diffDays} days`;
  };

  return (
    <AppShell>
      <div className="p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-purple-800">
              {greeting}, {user?.name || "Guest"}
            </h1>
            <p className="text-gray-500 text-sm">
              {new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}
            </p>
          </div>
        </div>
        
        {/* Next Routine Card */}
        <Card className="bg-gradient-to-r from-purple-500 to-purple-700 text-white shadow-lg">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Next Up</CardTitle>
          </CardHeader>
          <CardContent>
            {nextSchedule ? (
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <h3 className="text-xl font-bold">{nextSchedule.title}</h3>
                  <span className="text-sm bg-white/20 px-2 py-1 rounded">
                    {formatTime(nextSchedule.startTime)}
                  </span>
                </div>
                <p className="text-sm opacity-90">{getRelativeTime(nextSchedule.startTime)}</p>
                <Button
                  variant="secondary"
                  className="mt-2 w-full bg-white text-purple-700 hover:bg-gray-100"
                  size="sm"
                >
                  Start Now
                </Button>
              </div>
            ) : (
              <div className="text-center py-4">
                <p>No upcoming routines</p>
                <Button
                  variant="secondary"
                  className="mt-2 bg-white text-purple-700 hover:bg-gray-100"
                  size="sm"
                >
                  Create Routine
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Quick Access Section */}
        <div className="space-y-2">
          <h2 className="text-lg font-semibold text-gray-800">Quick Access</h2>
          <div className="grid grid-cols-3 gap-2">
            <Card className="bg-pink-50">
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <Sun className="h-6 w-6 text-pink-600 mb-1" />
                <p className="text-xs font-medium text-center">Morning Routine</p>
              </CardContent>
            </Card>
            <Card className="bg-blue-50">
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <Moon className="h-6 w-6 text-blue-600 mb-1" />
                <p className="text-xs font-medium text-center">Evening Routine</p>
              </CardContent>
            </Card>
            <Card className="bg-green-50">
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <Heart className="h-6 w-6 text-green-600 mb-1" />
                <p className="text-xs font-medium text-center">Health Check</p>
              </CardContent>
            </Card>
          </div>
        </div>
        
        {/* Today's Routines */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-800">Today's Routines</h2>
            <Button variant="ghost" size="sm" className="text-purple-700">
              View All
            </Button>
          </div>
          
          {isLoading ? (
            <p className="text-center py-6 text-sm text-gray-500">Loading your routines...</p>
          ) : schedules && schedules.length > 0 ? (
            <div className="space-y-2">
              {schedules.slice(0, 3).map((schedule) => (
                <Card key={schedule.id} className="overflow-hidden">
                  <CardContent className="p-3">
                    <div className="flex items-center">
                      <div 
                        className={`w-2 h-full mr-3 ${
                          schedule.type === "skincare" 
                            ? "bg-pink-400" 
                            : schedule.type === "haircare" 
                            ? "bg-blue-400" 
                            : "bg-green-400"
                        }`}
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-medium">{schedule.title}</h3>
                        <p className="text-xs text-gray-500">
                          {formatTime(schedule.startTime)}
                        </p>
                      </div>
                      <Button variant="outline" size="sm" className="h-8">
                        View
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-gray-500">No routines scheduled for today</p>
                <Button variant="outline" className="mt-4 text-purple-700 border-purple-700">
                  Create Routine
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
        
        {/* Self-Care Tips */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Today's Self-Care Tip</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600">
              "Stay hydrated! Drinking 8 glasses of water daily improves skin complexion, energizes muscles, and helps maintain organ function."
            </p>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
