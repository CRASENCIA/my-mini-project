import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, X, ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AppShell } from "@/components/layout/AppShell";
import { RecipeCard } from "@/components/diy/RecipeCard";
import { DiyRecipe } from "@shared/schema";
import { Badge } from "@/components/ui/badge";

export default function DIY() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedRecipe, setSelectedRecipe] = useState<DiyRecipe | null>(null);
  
  // Fetch DIY recipes
  const { data: recipes, isLoading } = useQuery<DiyRecipe[]>({
    queryKey: [selectedCategory ? `/api/diy-recipes?category=${selectedCategory}` : "/api/diy-recipes"],
  });
  
  // Filter recipes by search query
  const filteredRecipes = recipes?.filter(recipe => 
    recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    recipe.description.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Handle recipe selection
  const handleSelectRecipe = (id: number) => {
    const recipe = recipes?.find(r => r.id === id);
    if (recipe) {
      setSelectedRecipe(recipe);
    }
  };
  
  // Filter recipes by category
  const skincareRecipes = recipes?.filter(recipe => recipe.category === "skincare") || [];
  const haircareRecipes = recipes?.filter(recipe => recipe.category === "haircare") || [];
  
  return (
    <AppShell>
      <div className="p-4 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-purple-800">DIY Remedies</h1>
        </div>
        
        <div className="relative">
          <Input
            placeholder="Search recipes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10"
          />
          {searchQuery ? (
            <button
              className="absolute right-3 top-1/2 -translate-y-1/2"
              onClick={() => setSearchQuery("")}
            >
              <X className="h-4 w-4 text-gray-400" />
            </button>
          ) : (
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          )}
        </div>
        
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger 
              value="all" 
              onClick={() => setSelectedCategory(null)}
            >
              All
            </TabsTrigger>
            <TabsTrigger 
              value="skincare" 
              onClick={() => setSelectedCategory("skincare")}
            >
              Skincare
            </TabsTrigger>
            <TabsTrigger 
              value="haircare" 
              onClick={() => setSelectedCategory("haircare")}
            >
              Haircare
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="mt-4">
            {isLoading ? (
              <p className="text-center py-10 text-gray-500">Loading recipes...</p>
            ) : filteredRecipes && filteredRecipes.length > 0 ? (
              <div className="grid grid-cols-2 gap-4">
                {filteredRecipes.map(recipe => (
                  <RecipeCard 
                    key={recipe.id} 
                    recipe={recipe} 
                    onSelect={handleSelectRecipe} 
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-10">
                <p className="text-gray-500">No recipes found</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="skincare" className="mt-4">
            {isLoading ? (
              <p className="text-center py-10 text-gray-500">Loading recipes...</p>
            ) : skincareRecipes.length > 0 ? (
              <div className="grid grid-cols-2 gap-4">
                {skincareRecipes
                  .filter(recipe => recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            recipe.description.toLowerCase().includes(searchQuery.toLowerCase()))
                  .map(recipe => (
                    <RecipeCard 
                      key={recipe.id} 
                      recipe={recipe} 
                      onSelect={handleSelectRecipe} 
                    />
                  ))}
              </div>
            ) : (
              <div className="text-center py-10">
                <p className="text-gray-500">No skincare recipes found</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="haircare" className="mt-4">
            {isLoading ? (
              <p className="text-center py-10 text-gray-500">Loading recipes...</p>
            ) : haircareRecipes.length > 0 ? (
              <div className="grid grid-cols-2 gap-4">
                {haircareRecipes
                  .filter(recipe => recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            recipe.description.toLowerCase().includes(searchQuery.toLowerCase()))
                  .map(recipe => (
                    <RecipeCard 
                      key={recipe.id} 
                      recipe={recipe} 
                      onSelect={handleSelectRecipe} 
                    />
                  ))}
              </div>
            ) : (
              <div className="text-center py-10">
                <p className="text-gray-500">No haircare recipes found</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Recipe Detail Dialog */}
      <Dialog open={!!selectedRecipe} onOpenChange={() => setSelectedRecipe(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-xl text-purple-800">{selectedRecipe?.name}</DialogTitle>
            <DialogDescription>
              {selectedRecipe?.category.charAt(0).toUpperCase() + selectedRecipe?.category.slice(1)} Recipe
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-gray-700">{selectedRecipe?.description}</p>
            
            <div>
              <h3 className="text-sm font-medium mb-2">Good for:</h3>
              <div className="flex flex-wrap gap-1">
                {selectedRecipe?.forSkinType && selectedRecipe.forSkinType.map((type, index) => (
                  <Badge key={index} variant="secondary" className="bg-purple-100 text-purple-800">
                    {type}
                  </Badge>
                ))}
                {selectedRecipe?.forHairType && selectedRecipe.forHairType.map((type, index) => (
                  <Badge key={index} variant="secondary" className="bg-purple-100 text-purple-800">
                    {type}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium mb-2">Ingredients:</h3>
              <ul className="list-disc pl-5 text-sm space-y-1">
                {selectedRecipe?.ingredients.map((ingredient, index) => (
                  <li key={index}>{ingredient}</li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="text-sm font-medium mb-2">Instructions:</h3>
              <p className="text-sm text-gray-700">{selectedRecipe?.instructions}</p>
            </div>
            
            <Button 
              className="w-full bg-purple-800 hover:bg-purple-900 mt-4"
              onClick={() => setSelectedRecipe(null)}
            >
              Close
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
