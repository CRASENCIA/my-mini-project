import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CheckCircle, ChevronLeft, Clock, Edit, Plus, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { AppShell } from "@/components/layout/AppShell";
import { SkincareRoutine } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation, useParams } from "wouter";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useState } from "react";
import { useSchedule } from "@/hooks/use-schedule";

export default function SkincareRoutineDetail() {
  const { id } = useParams();
  const routineId = parseInt(id);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [_, setLocation] = useLocation();
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const { createSchedule } = useSchedule();
  
  // Format time of day
  const formatTimeOfDay = (timeOfDay: string) => {
    switch (timeOfDay) {
      case "morning":
        return "Morning Routine";
      case "evening":
        return "Evening Routine";
      case "weekly":
        return "Weekly Routine";
      default:
        return timeOfDay.charAt(0).toUpperCase() + timeOfDay.slice(1);
    }
  };
  
  // Fetch routine details
  const { data: routine, isLoading } = useQuery<SkincareRoutine>({
    queryKey: [`/api/skincare-routines/${routineId}`],
    enabled: !isNaN(routineId),
  });
  
  // Parse steps from JSON
  const steps = routine?.steps ? (typeof routine.steps === 'string' ? JSON.parse(routine.steps as string) : routine.steps) : [];
  
  // Delete routine mutation
  const deleteRoutine = useMutation({
    mutationFn: async () => {
      return apiRequest("DELETE", `/api/skincare-routines/${routineId}`, null);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/skincare-routines"] });
      toast({
        title: "Routine deleted",
        description: "Your skincare routine has been deleted successfully",
      });
      setLocation("/skincare");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete routine",
        variant: "destructive",
      });
    }
  });
  
  // Handle schedule creation
  const handleSchedule = () => {
    if (!routine) return;
    
    // Determine default time based on time of day
    const defaultTime = new Date();
    if (routine.timeOfDay === "morning") {
      defaultTime.setHours(8, 0, 0, 0);
    } else if (routine.timeOfDay === "evening") {
      defaultTime.setHours(20, 0, 0, 0);
    } else {
      defaultTime.setHours(10, 0, 0, 0);
    }
    
    const scheduleData = {
      title: routine.name,
      description: routine.description || `${formatTimeOfDay(routine.timeOfDay)} skincare routine`,
      type: "skincare",
      startTime: defaultTime.toISOString(),
      routineId: routine.id,
    };
    
    createSchedule.mutate(scheduleData, {
      onSuccess: () => {
        toast({
          title: "Routine scheduled",
          description: "Your skincare routine has been added to your schedule",
        });
      }
    });
  };
  
  // Handle delete confirmation
  const handleDeleteConfirm = () => {
    deleteRoutine.mutate();
    setShowDeleteDialog(false);
  };
  
  if (isLoading) {
    return (
      <AppShell>
        <div className="p-4 text-center">
          <p>Loading routine details...</p>
        </div>
      </AppShell>
    );
  }
  
  if (!routine) {
    return (
      <AppShell>
        <div className="p-4 text-center">
          <p>Routine not found</p>
          <Button 
            className="mt-4 bg-purple-800 hover:bg-purple-900"
            onClick={() => setLocation("/skincare")}
          >
            Back to Skincare
          </Button>
        </div>
      </AppShell>
    );
  }
  
  return (
    <AppShell>
      <div className="p-4 space-y-6">
        <div className="flex items-center space-x-2">
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-gray-500"
            onClick={() => setLocation("/skincare")}
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back
          </Button>
        </div>
        
        <div className="space-y-4">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-2xl font-bold text-purple-800">{routine.name}</h1>
              <div className="flex items-center mt-1 text-sm text-gray-500">
                <Clock className="h-4 w-4 mr-1" />
                <span>{formatTimeOfDay(routine.timeOfDay)}</span>
              </div>
            </div>
            
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="text-red-600"
                onClick={() => setShowDeleteDialog(true)}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setLocation(`/skincare/edit/${routine.id}`)}
              >
                <Edit className="h-4 w-4 mr-1" />
                Edit
              </Button>
            </div>
          </div>
          
          {routine.description && (
            <p className="text-gray-600">{routine.description}</p>
          )}
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Routine Steps</CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-4">
                {steps.map((step: any, index: number) => (
                  <li key={index} className="flex items-start">
                    <div className="flex-shrink-0 w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center mr-3 text-purple-800 font-semibold">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">{step.product || step.name}</h3>
                      {step.description && (
                        <p className="text-sm text-gray-600 mt-1">{step.description}</p>
                      )}
                    </div>
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
          
          <div className="flex justify-center space-x-3 pt-4">
            <Button 
              className="bg-purple-800 hover:bg-purple-900"
              onClick={handleSchedule}
              disabled={createSchedule.isPending}
            >
              <Plus className="h-4 w-4 mr-1" />
              Schedule Routine
            </Button>
            <Button variant="secondary">
              <CheckCircle className="h-4 w-4 mr-1" />
              Start Now
            </Button>
          </div>
        </div>
      </div>
      
      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Routine</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this skincare routine? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowDeleteDialog(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive"
              onClick={handleDeleteConfirm}
              disabled={deleteRoutine.isPending}
            >
              {deleteRoutine.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
