import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./lib/auth.tsx";

// Pages
import NotFound from "@/pages/not-found";
import Welcome from "@/pages/welcome";
import Login from "@/pages/login";
import Signup from "@/pages/signup";
import ProfileSetup from "@/pages/profile-setup";
import Home from "@/pages/home";
import Skincare from "@/pages/skincare";
import SkincareQuiz from "@/pages/skincare-quiz";
import SkincareRoutine from "@/pages/skincare-routine";
import Haircare from "@/pages/haircare";
import HaircareQuiz from "@/pages/haircare-quiz";
import HaircareRoutine from "@/pages/haircare-routine";
import Health from "@/pages/health";
import Scheduler from "@/pages/scheduler";
import DIY from "@/pages/diy";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Welcome} />
      <Route path="/login" component={Login} />
      <Route path="/signup" component={Signup} />
      <Route path="/profile-setup" component={ProfileSetup} />
      <Route path="/home" component={Home} />
      <Route path="/skincare" component={Skincare} />
      <Route path="/skincare-quiz" component={SkincareQuiz} />
      <Route path="/skincare-routine/:id" component={SkincareRoutine} />
      <Route path="/haircare" component={Haircare} />
      <Route path="/haircare-quiz" component={HaircareQuiz} />
      <Route path="/haircare-routine/:id" component={HaircareRoutine} />
      <Route path="/health" component={Health} />
      <Route path="/scheduler" component={Scheduler} />
      <Route path="/diy" component={DIY} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
