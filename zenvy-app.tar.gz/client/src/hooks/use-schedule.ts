import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Schedule } from "@shared/schema";

export function useSchedule() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const createSchedule = useMutation({
    mutationFn: async (data: Partial<Schedule>) => {
      setIsLoading(true);
      try {
        const response = await apiRequest("POST", "/api/schedules", data);
        return await response.json();
      } finally {
        setIsLoading(false);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      toast({
        title: "Schedule created",
        description: "Your schedule has been added successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create schedule",
        variant: "destructive",
      });
    },
  });

  const updateSchedule = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Schedule> }) => {
      setIsLoading(true);
      try {
        const response = await apiRequest("PUT", `/api/schedules/${id}`, data);
        return await response.json();
      } finally {
        setIsLoading(false);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      toast({
        title: "Schedule updated",
        description: "Your schedule has been updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update schedule",
        variant: "destructive",
      });
    },
  });

  const completeSchedule = useMutation({
    mutationFn: async (id: number) => {
      setIsLoading(true);
      try {
        const response = await apiRequest("PUT", `/api/schedules/${id}/complete`, {});
        return await response.json();
      } finally {
        setIsLoading(false);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      toast({
        title: "Schedule completed",
        description: "Schedule marked as completed",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update schedule",
        variant: "destructive",
      });
    },
  });

  const deleteSchedule = useMutation({
    mutationFn: async (id: number) => {
      setIsLoading(true);
      try {
        await apiRequest("DELETE", `/api/schedules/${id}`, null);
      } finally {
        setIsLoading(false);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      toast({
        title: "Schedule deleted",
        description: "Your schedule has been removed",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete schedule",
        variant: "destructive",
      });
    },
  });

  return {
    isLoading,
    createSchedule,
    updateSchedule,
    completeSchedule,
    deleteSchedule,
  };
}
