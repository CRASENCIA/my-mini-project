import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  name: text("name"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// User profiles table for details like skin type, hair type, etc.
export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  skinType: text("skin_type"),
  hairType: text("hair_type"),
  hasSensitiveSkin: boolean("has_sensitive_skin"),
  hasAcne: boolean("has_acne"),
  hasDandruff: boolean("has_dandruff"),
  weight: integer("weight"), // in kg
  height: integer("height"), // in cm
  birthdate: timestamp("birthdate"),
  gender: text("gender"),
  concerns: text("concerns").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Skincare routines table
export const skincareRoutines = pgTable("skincare_routines", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  timeOfDay: text("time_of_day").notNull(), // morning, evening
  steps: jsonb("steps").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Haircare routines table
export const haircareRoutines = pgTable("haircare_routines", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  frequency: text("frequency").notNull(), // daily, weekly
  steps: jsonb("steps").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// DIY Recipes table
export const diyRecipes = pgTable("diy_recipes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  ingredients: text("ingredients").array().notNull(),
  instructions: text("instructions").notNull(),
  category: text("category").notNull(), // skincare, haircare
  forSkinType: text("for_skin_type").array(),
  forHairType: text("for_hair_type").array(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// User schedules table
export const schedules = pgTable("schedules", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  isCompleted: boolean("is_completed").default(false).notNull(),
  type: text("type").notNull(), // skincare, haircare, health
  routineId: integer("routine_id"), // can be null for one-off tasks
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Health logs table for tracking progress
export const healthLogs = pgTable("health_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  weight: integer("weight"), // in kg
  height: integer("height"), // in cm
  bmi: text("bmi"),
  notes: text("notes"),
  logDate: timestamp("log_date").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Define relations
export const usersRelations = relations(users, ({ one, many }) => ({
  profile: one(userProfiles, {
    fields: [users.id],
    references: [userProfiles.userId],
  }),
  skincareRoutines: many(skincareRoutines),
  haircareRoutines: many(haircareRoutines),
  schedules: many(schedules),
  healthLogs: many(healthLogs),
}));

export const userProfilesRelations = relations(userProfiles, ({ one }) => ({
  user: one(users, {
    fields: [userProfiles.userId],
    references: [users.id],
  }),
}));

export const skincareRoutinesRelations = relations(skincareRoutines, ({ one, many }) => ({
  user: one(users, {
    fields: [skincareRoutines.userId],
    references: [users.id],
  }),
  schedules: many(schedules),
}));

export const haircareRoutinesRelations = relations(haircareRoutines, ({ one, many }) => ({
  user: one(users, {
    fields: [haircareRoutines.userId],
    references: [users.id],
  }),
  schedules: many(schedules),
}));

export const schedulesRelations = relations(schedules, ({ one }) => ({
  user: one(users, {
    fields: [schedules.userId],
    references: [users.id],
  }),
}));

export const healthLogsRelations = relations(healthLogs, ({ one }) => ({
  user: one(users, {
    fields: [healthLogs.userId],
    references: [users.id],
  }),
}));

// Define schemas for validation
export const userInsertSchema = createInsertSchema(users, {
  username: (schema) => schema.min(3, "Username must be at least 3 characters"),
  password: (schema) => schema.min(6, "Password must be at least 6 characters"),
  email: (schema) => schema.email("Must provide a valid email"),
});

export const userLoginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const userProfileInsertSchema = createInsertSchema(userProfiles);
export const skincareRoutineInsertSchema = createInsertSchema(skincareRoutines);
export const haircareRoutineInsertSchema = createInsertSchema(haircareRoutines);
export const scheduleInsertSchema = createInsertSchema(schedules);
export const healthLogInsertSchema = createInsertSchema(healthLogs);
export const diyRecipeInsertSchema = createInsertSchema(diyRecipes);

// Export types
export type User = typeof users.$inferSelect;
export type UserInsert = z.infer<typeof userInsertSchema>;
export type UserLogin = z.infer<typeof userLoginSchema>;
export type UserProfile = typeof userProfiles.$inferSelect;
export type UserProfileInsert = z.infer<typeof userProfileInsertSchema>;
export type SkincareRoutine = typeof skincareRoutines.$inferSelect;
export type SkincareRoutineInsert = z.infer<typeof skincareRoutineInsertSchema>;
export type HaircareRoutine = typeof haircareRoutines.$inferSelect;
export type HaircareRoutineInsert = z.infer<typeof haircareRoutineInsertSchema>;
export type Schedule = typeof schedules.$inferSelect;
export type ScheduleInsert = z.infer<typeof scheduleInsertSchema>;
export type HealthLog = typeof healthLogs.$inferSelect;
export type HealthLogInsert = z.infer<typeof healthLogInsertSchema>;
export type DiyRecipe = typeof diyRecipes.$inferSelect;
export type DiyRecipeInsert = z.infer<typeof diyRecipeInsertSchema>;
