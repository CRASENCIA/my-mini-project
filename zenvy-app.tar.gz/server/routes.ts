import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import session from "express-session";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { z } from "zod";
import { userInsertSchema, userLoginSchema, userProfileInsertSchema, skincareRoutineInsertSchema, haircareRoutineInsertSchema, scheduleInsertSchema, healthLogInsertSchema } from "@shared/schema";
import connectPgSimple from "connect-pg-simple";
import { pool } from "@db";

// Set up authentication middleware
const setupAuth = (app: Express) => {
  // Configure passport
  passport.use(new LocalStrategy(
    async (username, password, done) => {
      try {
        const user = await storage.validateUser(username, password);
        if (!user) {
          return done(null, false, { message: "Incorrect username or password" });
        }
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    }
  ));

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUserById(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Set up session
  const PgSession = connectPgSimple(session);
  
  app.use(session({
    store: new PgSession({
      pool,
      tableName: "session",
      createTableIfMissing: true,
    }),
    secret: process.env.SESSION_SECRET || "zenvy-secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      secure: process.env.NODE_ENV === "production",
    }
  }));

  app.use(passport.initialize());
  app.use(passport.session());
};

// Authentication middleware
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Auth routes
  app.post('/api/auth/signup', async (req, res) => {
    try {
      const { username, email, password, name } = userInsertSchema.parse(req.body);
      
      // Check if user exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already exists" });
      }
      
      const user = await storage.createUser(username, email, password, name);
      
      // Auto login after signup
      req.login(user, (err) => {
        if (err) {
          return res.status(500).json({ message: "Error logging in after signup" });
        }
        return res.status(201).json({ id: user.id, username: user.username, email: user.email, name: user.name });
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      console.error("Error creating user:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post('/api/auth/login', (req, res, next) => {
    try {
      // Validate login data
      userLoginSchema.parse(req.body);
      
      passport.authenticate('local', (err, user, info) => {
        if (err) {
          return next(err);
        }
        if (!user) {
          return res.status(401).json({ message: info.message || "Invalid credentials" });
        }
        req.login(user, (err) => {
          if (err) {
            return next(err);
          }
          return res.json({ id: user.id, username: user.username, email: user.email, name: user.name });
        });
      })(req, res, next);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      res.json({ message: "Successfully logged out" });
    });
  });

  app.get('/api/auth/me', (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const user = req.user as any;
    res.json({ id: user.id, username: user.username, email: user.email, name: user.name });
  });

  // User profile routes
  app.post('/api/profile', isAuthenticated, async (req, res) => {
    try {
      const profileData = userProfileInsertSchema.parse(req.body);
      const user = req.user as any;
      
      const existingProfile = await storage.getUserProfile(user.id);
      if (existingProfile) {
        return res.status(400).json({ message: "Profile already exists" });
      }
      
      const profile = await storage.createUserProfile(user.id, profileData);
      return res.status(201).json(profile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get('/api/profile', isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const profile = await storage.getUserProfile(user.id);
    if (!profile) {
      return res.status(404).json({ message: "Profile not found" });
    }
    res.json(profile);
  });

  app.put('/api/profile', isAuthenticated, async (req, res) => {
    try {
      const profileData = req.body;
      const user = req.user as any;
      
      const profile = await storage.updateUserProfile(user.id, profileData);
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      
      return res.json(profile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Skincare routines routes
  app.post('/api/skincare-routines', isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const routineData = skincareRoutineInsertSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const routine = await storage.createSkincareRoutine(routineData);
      res.status(201).json(routine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get('/api/skincare-routines', isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const routines = await storage.getUserSkincareRoutines(user.id);
    res.json(routines);
  });

  app.get('/api/skincare-routines/:id', isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    const routine = await storage.getSkincareRoutineById(id);
    
    if (!routine) {
      return res.status(404).json({ message: "Routine not found" });
    }
    
    const user = req.user as any;
    if (routine.userId !== user.id) {
      return res.status(403).json({ message: "Unauthorized access to this routine" });
    }
    
    res.json(routine);
  });

  app.put('/api/skincare-routines/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = req.user as any;
      
      const routine = await storage.getSkincareRoutineById(id);
      if (!routine) {
        return res.status(404).json({ message: "Routine not found" });
      }
      
      if (routine.userId !== user.id) {
        return res.status(403).json({ message: "Unauthorized access to this routine" });
      }
      
      const updatedRoutine = await storage.updateSkincareRoutine(id, req.body);
      res.json(updatedRoutine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete('/api/skincare-routines/:id', isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    const user = req.user as any;
    
    const routine = await storage.getSkincareRoutineById(id);
    if (!routine) {
      return res.status(404).json({ message: "Routine not found" });
    }
    
    if (routine.userId !== user.id) {
      return res.status(403).json({ message: "Unauthorized access to this routine" });
    }
    
    const success = await storage.deleteSkincareRoutine(id);
    if (success) {
      res.status(204).end();
    } else {
      res.status(500).json({ message: "Failed to delete routine" });
    }
  });

  // Haircare routines routes
  app.post('/api/haircare-routines', isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const routineData = haircareRoutineInsertSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const routine = await storage.createHaircareRoutine(routineData);
      res.status(201).json(routine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get('/api/haircare-routines', isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const routines = await storage.getUserHaircareRoutines(user.id);
    res.json(routines);
  });

  app.get('/api/haircare-routines/:id', isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    const routine = await storage.getHaircareRoutineById(id);
    
    if (!routine) {
      return res.status(404).json({ message: "Routine not found" });
    }
    
    const user = req.user as any;
    if (routine.userId !== user.id) {
      return res.status(403).json({ message: "Unauthorized access to this routine" });
    }
    
    res.json(routine);
  });

  app.put('/api/haircare-routines/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = req.user as any;
      
      const routine = await storage.getHaircareRoutineById(id);
      if (!routine) {
        return res.status(404).json({ message: "Routine not found" });
      }
      
      if (routine.userId !== user.id) {
        return res.status(403).json({ message: "Unauthorized access to this routine" });
      }
      
      const updatedRoutine = await storage.updateHaircareRoutine(id, req.body);
      res.json(updatedRoutine);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete('/api/haircare-routines/:id', isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    const user = req.user as any;
    
    const routine = await storage.getHaircareRoutineById(id);
    if (!routine) {
      return res.status(404).json({ message: "Routine not found" });
    }
    
    if (routine.userId !== user.id) {
      return res.status(403).json({ message: "Unauthorized access to this routine" });
    }
    
    const success = await storage.deleteHaircareRoutine(id);
    if (success) {
      res.status(204).end();
    } else {
      res.status(500).json({ message: "Failed to delete routine" });
    }
  });

  // DIY Recipes routes
  app.get('/api/diy-recipes', async (req, res) => {
    const category = req.query.category as string;
    
    let recipes;
    if (category) {
      recipes = await storage.getDiyRecipesByCategory(category);
    } else {
      recipes = await storage.getAllDiyRecipes();
    }
    
    res.json(recipes);
  });

  app.get('/api/diy-recipes/:id', async (req, res) => {
    const id = parseInt(req.params.id);
    const recipe = await storage.getDiyRecipeById(id);
    
    if (!recipe) {
      return res.status(404).json({ message: "Recipe not found" });
    }
    
    res.json(recipe);
  });

  // Schedule routes
  app.post('/api/schedules', isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const scheduleData = scheduleInsertSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const schedule = await storage.createSchedule(scheduleData);
      res.status(201).json(schedule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get('/api/schedules', isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const dateParam = req.query.date as string;
    
    if (dateParam) {
      const date = new Date(dateParam);
      if (isNaN(date.getTime())) {
        return res.status(400).json({ message: "Invalid date format" });
      }
      
      const schedules = await storage.getUserDailySchedules(user.id, date);
      return res.json(schedules);
    }
    
    const upcoming = req.query.upcoming === 'true';
    
    let schedules;
    if (upcoming) {
      schedules = await storage.getUserUpcomingSchedules(user.id);
    } else {
      schedules = await storage.getUserSchedules(user.id);
    }
    
    res.json(schedules);
  });

  app.get('/api/schedules/:id', isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    const schedule = await storage.getScheduleById(id);
    
    if (!schedule) {
      return res.status(404).json({ message: "Schedule not found" });
    }
    
    const user = req.user as any;
    if (schedule.userId !== user.id) {
      return res.status(403).json({ message: "Unauthorized access to this schedule" });
    }
    
    res.json(schedule);
  });

  app.put('/api/schedules/:id', isAuthenticated, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = req.user as any;
      
      const schedule = await storage.getScheduleById(id);
      if (!schedule) {
        return res.status(404).json({ message: "Schedule not found" });
      }
      
      if (schedule.userId !== user.id) {
        return res.status(403).json({ message: "Unauthorized access to this schedule" });
      }
      
      const updatedSchedule = await storage.updateSchedule(id, req.body);
      res.json(updatedSchedule);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put('/api/schedules/:id/complete', isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    const user = req.user as any;
    
    const schedule = await storage.getScheduleById(id);
    if (!schedule) {
      return res.status(404).json({ message: "Schedule not found" });
    }
    
    if (schedule.userId !== user.id) {
      return res.status(403).json({ message: "Unauthorized access to this schedule" });
    }
    
    const updatedSchedule = await storage.markScheduleComplete(id);
    res.json(updatedSchedule);
  });

  app.delete('/api/schedules/:id', isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    const user = req.user as any;
    
    const schedule = await storage.getScheduleById(id);
    if (!schedule) {
      return res.status(404).json({ message: "Schedule not found" });
    }
    
    if (schedule.userId !== user.id) {
      return res.status(403).json({ message: "Unauthorized access to this schedule" });
    }
    
    const success = await storage.deleteSchedule(id);
    if (success) {
      res.status(204).end();
    } else {
      res.status(500).json({ message: "Failed to delete schedule" });
    }
  });

  // Health logs routes
  app.post('/api/health-logs', isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const logData = healthLogInsertSchema.parse({
        ...req.body,
        userId: user.id
      });
      
      const log = await storage.createHealthLog(logData);
      res.status(201).json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ errors: error.errors });
      }
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get('/api/health-logs', isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    
    const logs = await storage.getUserHealthLogs(user.id, limit);
    res.json(logs);
  });

  app.get('/api/health-logs/latest', isAuthenticated, async (req, res) => {
    const user = req.user as any;
    const log = await storage.getLatestHealthLog(user.id);
    
    if (!log) {
      return res.status(404).json({ message: "No health logs found" });
    }
    
    res.json(log);
  });

  const httpServer = createServer(app);
  return httpServer;
}
