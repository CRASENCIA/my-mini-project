import { db } from "@db";
import { 
  users, 
  userProfiles, 
  skincareRoutines, 
  haircareRoutines, 
  diyRecipes, 
  schedules, 
  healthLogs,
  User,
  UserProfile,
  SkincareRoutine,
  HaircareRoutine,
  DiyRecipe,
  Schedule,
  HealthLog
} from "@shared/schema";
import { eq, and, desc, asc, gte, lt } from "drizzle-orm";
import * as bcrypt from "bcrypt";

// User methods
export const storage = {
  // User operations
  async createUser(username: string, email: string, password: string, name?: string): Promise<User> {
    const hashedPassword = await bcrypt.hash(password, 10);
    const [user] = await db
      .insert(users)
      .values({
        username,
        email,
        password: hashedPassword,
        name,
      })
      .returning();
    return user;
  },

  async getUserByUsername(username: string): Promise<User | undefined> {
    return await db.query.users.findFirst({
      where: eq(users.username, username),
    });
  },

  async getUserById(id: number): Promise<User | undefined> {
    return await db.query.users.findFirst({
      where: eq(users.id, id),
    });
  },

  async getUserByEmail(email: string): Promise<User | undefined> {
    return await db.query.users.findFirst({
      where: eq(users.email, email),
    });
  },

  async validateUser(username: string, password: string): Promise<User | null> {
    const user = await this.getUserByUsername(username);
    if (!user) return null;
    
    const isValid = await bcrypt.compare(password, user.password);
    return isValid ? user : null;
  },

  // User profile operations
  async createUserProfile(userId: number, profileData: Partial<UserProfile>): Promise<UserProfile> {
    const [profile] = await db
      .insert(userProfiles)
      .values({
        userId,
        ...profileData,
      })
      .returning();
    return profile;
  },

  async getUserProfile(userId: number): Promise<UserProfile | undefined> {
    return await db.query.userProfiles.findFirst({
      where: eq(userProfiles.userId, userId),
    });
  },

  async updateUserProfile(userId: number, profileData: Partial<UserProfile>): Promise<UserProfile | undefined> {
    const [profile] = await db
      .update(userProfiles)
      .set({
        ...profileData,
        updatedAt: new Date(),
      })
      .where(eq(userProfiles.userId, userId))
      .returning();
    return profile;
  },

  // Skincare routines operations
  async createSkincareRoutine(data: Partial<SkincareRoutine>): Promise<SkincareRoutine> {
    const [routine] = await db
      .insert(skincareRoutines)
      .values(data)
      .returning();
    return routine;
  },

  async getUserSkincareRoutines(userId: number): Promise<SkincareRoutine[]> {
    return await db.query.skincareRoutines.findMany({
      where: eq(skincareRoutines.userId, userId),
      orderBy: asc(skincareRoutines.timeOfDay),
    });
  },

  async getSkincareRoutineById(id: number): Promise<SkincareRoutine | undefined> {
    return await db.query.skincareRoutines.findFirst({
      where: eq(skincareRoutines.id, id),
    });
  },

  async updateSkincareRoutine(id: number, data: Partial<SkincareRoutine>): Promise<SkincareRoutine | undefined> {
    const [routine] = await db
      .update(skincareRoutines)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(skincareRoutines.id, id))
      .returning();
    return routine;
  },

  async deleteSkincareRoutine(id: number): Promise<boolean> {
    const deleted = await db
      .delete(skincareRoutines)
      .where(eq(skincareRoutines.id, id))
      .returning({ id: skincareRoutines.id });
    return deleted.length > 0;
  },

  // Haircare routines operations
  async createHaircareRoutine(data: Partial<HaircareRoutine>): Promise<HaircareRoutine> {
    const [routine] = await db
      .insert(haircareRoutines)
      .values(data)
      .returning();
    return routine;
  },

  async getUserHaircareRoutines(userId: number): Promise<HaircareRoutine[]> {
    return await db.query.haircareRoutines.findMany({
      where: eq(haircareRoutines.userId, userId),
    });
  },

  async getHaircareRoutineById(id: number): Promise<HaircareRoutine | undefined> {
    return await db.query.haircareRoutines.findFirst({
      where: eq(haircareRoutines.id, id),
    });
  },

  async updateHaircareRoutine(id: number, data: Partial<HaircareRoutine>): Promise<HaircareRoutine | undefined> {
    const [routine] = await db
      .update(haircareRoutines)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(haircareRoutines.id, id))
      .returning();
    return routine;
  },

  async deleteHaircareRoutine(id: number): Promise<boolean> {
    const deleted = await db
      .delete(haircareRoutines)
      .where(eq(haircareRoutines.id, id))
      .returning({ id: haircareRoutines.id });
    return deleted.length > 0;
  },

  // DIY Recipes operations
  async getAllDiyRecipes(): Promise<DiyRecipe[]> {
    return await db.query.diyRecipes.findMany({
      orderBy: asc(diyRecipes.name),
    });
  },

  async getDiyRecipesByCategory(category: string): Promise<DiyRecipe[]> {
    return await db.query.diyRecipes.findMany({
      where: eq(diyRecipes.category, category),
      orderBy: asc(diyRecipes.name),
    });
  },

  async getDiyRecipeById(id: number): Promise<DiyRecipe | undefined> {
    return await db.query.diyRecipes.findFirst({
      where: eq(diyRecipes.id, id),
    });
  },

  // Schedule operations
  async createSchedule(data: Partial<Schedule>): Promise<Schedule> {
    const [schedule] = await db
      .insert(schedules)
      .values(data)
      .returning();
    return schedule;
  },

  async getUserSchedules(userId: number): Promise<Schedule[]> {
    return await db.query.schedules.findMany({
      where: eq(schedules.userId, userId),
      orderBy: asc(schedules.startTime),
    });
  },

  async getUserUpcomingSchedules(userId: number): Promise<Schedule[]> {
    return await db.query.schedules.findMany({
      where: and(
        eq(schedules.userId, userId),
        gte(schedules.startTime, new Date()),
        eq(schedules.isCompleted, false)
      ),
      orderBy: asc(schedules.startTime),
    });
  },

  async getUserDailySchedules(userId: number, date: Date): Promise<Schedule[]> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    return await db.query.schedules.findMany({
      where: and(
        eq(schedules.userId, userId),
        gte(schedules.startTime, startOfDay),
        lt(schedules.startTime, endOfDay)
      ),
      orderBy: asc(schedules.startTime),
    });
  },

  async getScheduleById(id: number): Promise<Schedule | undefined> {
    return await db.query.schedules.findFirst({
      where: eq(schedules.id, id),
    });
  },

  async updateSchedule(id: number, data: Partial<Schedule>): Promise<Schedule | undefined> {
    const [schedule] = await db
      .update(schedules)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(schedules.id, id))
      .returning();
    return schedule;
  },

  async markScheduleComplete(id: number): Promise<Schedule | undefined> {
    const [schedule] = await db
      .update(schedules)
      .set({
        isCompleted: true,
        updatedAt: new Date(),
      })
      .where(eq(schedules.id, id))
      .returning();
    return schedule;
  },

  async deleteSchedule(id: number): Promise<boolean> {
    const deleted = await db
      .delete(schedules)
      .where(eq(schedules.id, id))
      .returning({ id: schedules.id });
    return deleted.length > 0;
  },

  // Health logs operations
  async createHealthLog(data: Partial<HealthLog>): Promise<HealthLog> {
    const [log] = await db
      .insert(healthLogs)
      .values(data)
      .returning();
    return log;
  },

  async getUserHealthLogs(userId: number, limit = 10): Promise<HealthLog[]> {
    return await db.query.healthLogs.findMany({
      where: eq(healthLogs.userId, userId),
      orderBy: desc(healthLogs.logDate),
      limit,
    });
  },

  async getLatestHealthLog(userId: number): Promise<HealthLog | undefined> {
    return await db.query.healthLogs.findFirst({
      where: eq(healthLogs.userId, userId),
      orderBy: desc(healthLogs.logDate),
    });
  },
};
