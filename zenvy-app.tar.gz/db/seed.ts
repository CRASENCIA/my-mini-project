import { db } from "./index";
import * as schema from "@shared/schema";

// Sample DIY recipes for seeding
const diyRecipes = [
  {
    name: "Honey Face Mask",
    description: "A hydrating mask for dry skin that soothes and moisturizes with natural ingredients.",
    ingredients: ["2 tablespoons raw honey", "1 teaspoon cinnamon", "1 teaspoon nutmeg"],
    instructions: "Mix all ingredients in a small bowl. Apply to clean, dry skin and leave on for 15-20 minutes. Rinse with warm water and pat dry.",
    category: "skincare",
    forSkinType: ["dry", "sensitive", "normal"],
    forHairType: [],
  },
  {
    name: "Clay Purifying Mask",
    description: "Deep cleansing mask that draws out impurities and excess oil from pores.",
    ingredients: ["1 tablespoon bentonite clay", "1 tablespoon apple cider vinegar", "1 teaspoon honey"],
    instructions: "Mix clay and vinegar in a non-metal bowl until smooth. Add honey and stir well. Apply to face avoiding eye area. Let dry for 10-15 minutes, then rinse with warm water.",
    category: "skincare",
    forSkinType: ["oily", "combination", "acne-prone"],
    forHairType: [],
  },
  {
    name: "Oatmeal Exfoliating Scrub",
    description: "Gentle exfoliating scrub to remove dead skin cells and brighten complexion.",
    ingredients: ["2 tablespoons ground oatmeal", "1 tablespoon yogurt", "1 teaspoon honey"],
    instructions: "Combine all ingredients in a bowl. Gently massage onto damp skin in circular motions. Rinse thoroughly with warm water.",
    category: "skincare",
    forSkinType: ["all", "sensitive", "dry"],
    forHairType: [],
  },
  {
    name: "Avocado Moisturizing Mask",
    description: "Rich in vitamins and natural oils for deep hydration and nourishment.",
    ingredients: ["1/2 ripe avocado", "1 tablespoon olive oil", "1 tablespoon honey"],
    instructions: "Mash avocado until smooth. Mix in olive oil and honey. Apply to clean face and leave for 15-20 minutes. Rinse with cool water.",
    category: "skincare",
    forSkinType: ["dry", "mature", "dehydrated"],
    forHairType: [],
  },
  {
    name: "Coffee Grounds Scrub",
    description: "Energizing scrub that helps improve circulation and reduce the appearance of cellulite.",
    ingredients: ["1/4 cup used coffee grounds", "2 tablespoons coconut oil", "1 tablespoon brown sugar"],
    instructions: "Mix all ingredients together. In the shower, apply to damp skin in circular motions. Rinse thoroughly.",
    category: "skincare",
    forSkinType: ["all", "body"],
    forHairType: [],
  },
  {
    name: "Green Tea Toner",
    description: "Antioxidant-rich toner that soothes inflammation and reduces redness.",
    ingredients: ["1 green tea bag", "1 cup hot water", "1 teaspoon honey", "2 drops tea tree oil (optional)"],
    instructions: "Steep tea bag in hot water for 5 minutes. Remove bag and let cool completely. Stir in honey and tea tree oil if using. Transfer to a spray bottle or container. Store in refrigerator for up to one week.",
    category: "skincare",
    forSkinType: ["all", "sensitive", "acne-prone"],
    forHairType: [],
  },
  {
    name: "Coconut Oil Hair Mask",
    description: "Deep conditioning treatment that penetrates hair shafts to moisturize and repair damage.",
    ingredients: ["3 tablespoons coconut oil", "1 tablespoon honey", "5 drops essential oil (optional)"],
    instructions: "Melt coconut oil if solid. Mix with honey and essential oil if using. Apply to damp hair focusing on ends. Cover with shower cap and leave for 30 minutes to overnight. Shampoo and condition as normal.",
    category: "haircare",
    forSkinType: [],
    forHairType: ["dry", "damaged", "curly", "coily"],
  },
  {
    name: "Apple Cider Vinegar Rinse",
    description: "Balances scalp pH, removes product buildup, and adds shine to hair.",
    ingredients: ["2 tablespoons apple cider vinegar", "2 cups water", "5 drops essential oil (optional)"],
    instructions: "Mix all ingredients in a squeeze bottle. After shampooing, pour mixture over hair and scalp. Let sit for 1-2 minutes, then rinse with cool water.",
    category: "haircare",
    forSkinType: [],
    forHairType: ["oily", "product buildup", "dull"],
  },
  {
    name: "Egg Protein Hair Treatment",
    description: "Strengthening treatment that adds protein to weak, damaged hair.",
    ingredients: ["2 eggs", "2 tablespoons olive oil", "1 tablespoon honey"],
    instructions: "Whisk eggs, then add olive oil and honey. Apply to damp hair from roots to ends. Cover with shower cap and leave for 20-30 minutes. Rinse with cool water (not hot, to avoid cooking the egg).",
    category: "haircare",
    forSkinType: [],
    forHairType: ["damaged", "weak", "brittle"],
  },
  {
    name: "Avocado and Banana Hair Mask",
    description: "Ultra-hydrating mask that nourishes dry, frizzy hair.",
    ingredients: ["1/2 ripe avocado", "1/2 ripe banana", "1 tablespoon olive oil"],
    instructions: "Blend ingredients until smooth with no chunks. Apply to damp hair, focusing on dry areas. Cover with shower cap and leave for 30 minutes. Rinse thoroughly and condition as normal.",
    category: "haircare",
    forSkinType: [],
    forHairType: ["dry", "frizzy", "curly"],
  },
  {
    name: "Aloe Vera Gel Hair Treatment",
    description: "Soothes scalp irritation and adds moisture without weighing hair down.",
    ingredients: ["3 tablespoons pure aloe vera gel", "2 tablespoons coconut oil", "5 drops tea tree oil (optional)"],
    instructions: "Mix all ingredients together. Massage into scalp and distribute through hair. Leave for 30 minutes. Shampoo and condition as normal.",
    category: "haircare",
    forSkinType: [],
    forHairType: ["dry scalp", "irritated scalp", "fine hair"],
  },
  {
    name: "Brown Sugar Lip Scrub",
    description: "Gentle exfoliant that removes dead skin from lips, leaving them soft and smooth.",
    ingredients: ["1 tablespoon brown sugar", "1 teaspoon honey", "1/2 teaspoon olive oil"],
    instructions: "Mix all ingredients together. Gently rub on lips in circular motions for 1-2 minutes. Rinse off or wipe with warm washcloth.",
    category: "skincare",
    forSkinType: ["lips", "all"],
    forHairType: [],
  }
];

async function seed() {
  try {
    console.log("🌱 Starting to seed database...");

    // Check if DIY recipes already exist
    const existingRecipes = await db.query.diyRecipes.findMany();
    if (existingRecipes.length > 0) {
      console.log(`Found ${existingRecipes.length} existing DIY recipes. Skipping seed.`);
      return;
    }

    // Insert DIY recipes
    console.log("Adding DIY recipes...");
    const insertedRecipes = await db.insert(schema.diyRecipes).values(diyRecipes).returning();
    console.log(`✅ Added ${insertedRecipes.length} DIY recipes to database`);

    console.log("✅ Database seeding completed");
  } catch (error) {
    console.error("❌ Error seeding database:", error);
  }
}

seed();
